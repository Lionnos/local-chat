## Ejecución del contenedor

El archivo `docker-compose.yml` incluye la creación de los servicios del motor de base de datos (MySQL) y su gestor (phpMyAdmin).

## Comandos para la ejecución del contenedor

*1.  Para construir la imagen:*
```sh
  docker-compose build
```

*2.  Para iniciar los servicios:*

```bash
  docker-compose up
```

Este archivo README proporciona las instrucciones necesarias para construir y ejecutar los contenedores Docker utilizando el archivo `docker-compose.yml`.
