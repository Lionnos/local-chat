-- Active: 1720819103449@@127.0.0.1@3306@dbapimafer

use dbapimafer;

CREATE TABLE `image-product` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `productId` char(36) NOT NULL,
  `url` varchar(255) NOT NULL
);

CREATE TABLE `taddition` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `productId` char(36) NOT NULL,
  `quantity` int NOT NULL,
  `changeDate` timestamp NOT NULL
);

CREATE TABLE `taddress` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `clientId` char(36) NOT NULL,
  `department` varchar(100) NOT NULL,
  `province` varchar(100) NOT NULL,
  `district` varchar(100) NOT NULL,
  `address` varchar(255) NOT NULL,
  `reference` varchar(255),
  `postalCode` varchar(20) NOT NULL,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL
);

CREATE TABLE `tblog` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `userId` char(36) NOT NULL,
  `title` text NOT NULL,
  `subtitle` text NOT NULL,
  `content` text NOT NULL,
  `status` tinyint NOT NULL,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL
);

CREATE TABLE `tcategory` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL
);

CREATE TABLE `tclient` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstName` varchar(95) NOT NULL,
  `lastName` varchar(95) NOT NULL,
  `email` varchar(59) NOT NULL,
  `documentType` varchar(45) NOT NULL,
  `documentNumber` varchar(20) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `role` ENUM ('Logged') NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL
);

CREATE TABLE `tcomment` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `content` text NOT NULL,
  `blogId` char(36) NOT NULL,
  `clientId` char(36) NOT NULL,
  `reaction` tinyint,
  `createAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL
);

CREATE TABLE `image-blog` (
  `id` char(36) NOT NULL,
  `blogId` char(36) NOT NULL,
  `url` varchar(255) NOT NULL
);

CREATE TABLE `torderstatus` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `saleId` char(36) NOT NULL,
  `status` varchar(20) NOT NULL,
  `statusChangedAt` timestamp NOT NULL
);

CREATE TABLE `tpayment` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `clientId` char(36) NOT NULL,
  `paymentMethod` varchar(50) NOT NULL,
  `paymentStatus` varchar(20) NOT NULL,
  `paymentDate` timestamp NOT NULL,
  `amount` decimal(10,2) NOT NULL
);

CREATE TABLE `tproduct` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `categoryId` char(36) NOT NULL,
  `name` varchar(95) NOT NULL,
  `description` text NOT NULL,
  `quantity` int NOT NULL,
  `status` tinyint(1) NOT NULL,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL
);

CREATE TABLE `treactions` (
  `id` int PRIMARY KEY NOT NULL,
  `type` tinyint,
  `createAt` datetime,
  `blogId` char(36) NOT NULL,
  `clientId` char(36) NOT NULL
);

CREATE TABLE `treport` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `reportType` varchar(50) NOT NULL,
  `generatedAt` timestamp NOT NULL,
  `reportData` longblob NOT NULL
);

CREATE TABLE `treview` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `productId` char(36) NOT NULL,
  `clientId` char(36) NOT NULL,
  `rating` int NOT NULL,
  `reviewText` text,
  `reviewDate` timestamp NOT NULL
);

CREATE TABLE `tsales` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `clientId` char(36) NOT NULL,
  `date` datetime NOT NULL,
  `totalPrice` decimal(10,2) NOT NULL,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL,
  `paymentId` char(36) NOT NULL
);

CREATE TABLE `tsalesdetails` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `productID` char(36) NOT NULL,
  `saleID` char(36) NOT NULL,
  `quantity` int NOT NULL,
  `unitPrice` decimal(10,2) NOT NULL,
  `subTotalPrice` decimal(10,2) NOT NULL
);

CREATE TABLE `tsaleshistory` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `saleID` char(36) NOT NULL,
  `status` varchar(20) NOT NULL,
  `changedAt` timestamp NOT NULL
);

CREATE TABLE `tsubtraction` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `productId` char(36) NOT NULL,
  `quantity` int NOT NULL,
  `changeDate` timestamp NOT NULL
);

CREATE TABLE `tuser` (
  `id` char(36) PRIMARY KEY NOT NULL,
  `username` varchar(50) UNIQUE NOT NULL,
  `password` varchar(255) NOT NULL,
  `firstName` varchar(95) NOT NULL,
  `lastName` varchar(95) NOT NULL,
  `email` varchar(59) UNIQUE NOT NULL,
  `dni` char(8) NOT NULL,
  `ruc` char(20) NULL,
  `address` char(100) NOT NULL,  
  `workArea` char(50) NOT NULL,
  `workDay` char(50) NOT NULL,
  `phoneNumber` varchar(20),
  `role` ENUM ('Manager','Admin','Employee','Other') NOT NULL,
  `status` tinyint(1) NOT NULL,
  `contractStartDate` timestamp NOT NULL,
  `dateOfResignation` timestamp NOT NULL,
  `createdAt` timestamp NOT NULL,
  `updatedAt` timestamp NOT NULL,
  `createdBy` char(36) NULL,
  `updatedBy` char(36) NULL
);


ALTER TABLE `image-product` ADD CONSTRAINT `image-product_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `tproduct` (`id`);
ALTER TABLE `taddition` ADD CONSTRAINT `taddition_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `tproduct` (`id`);
ALTER TABLE `taddress` ADD CONSTRAINT `taddress_ibfk_1` FOREIGN KEY (`clientId`) REFERENCES `tclient` (`id`);
ALTER TABLE `tblog` ADD CONSTRAINT `tblog_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `tuser` (`id`);
ALTER TABLE `tcomment` ADD CONSTRAINT `tcomment_ibfk_1` FOREIGN KEY (`blogId`) REFERENCES `tblog` (`id`);
ALTER TABLE `tcomment` ADD CONSTRAINT `tcomment_ibfk_2` FOREIGN KEY (`clientId`) REFERENCES `tclient` (`id`);
ALTER TABLE `torderstatus` ADD CONSTRAINT `torderstatus_ibfk_1` FOREIGN KEY (`saleId`) REFERENCES `tsales` (`id`);
ALTER TABLE `tproduct` ADD CONSTRAINT `tproduct_ibfk_1` FOREIGN KEY (`categoryId`) REFERENCES `tcategory` (`id`);
ALTER TABLE `treactions` ADD CONSTRAINT `treactions_ibfk_1` FOREIGN KEY (`blogId`) REFERENCES `tblog` (`id`);
ALTER TABLE `treactions` ADD CONSTRAINT `treactions_ibfk_2` FOREIGN KEY (`clientId`) REFERENCES `tclient` (`id`);
ALTER TABLE `treview` ADD CONSTRAINT `treview_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `tproduct` (`id`);
ALTER TABLE `treview` ADD CONSTRAINT `treview_ibfk_2` FOREIGN KEY (`clientId`) REFERENCES `tclient` (`id`);
ALTER TABLE `tsales` ADD CONSTRAINT `tsales_ibfk_1` FOREIGN KEY (`clientId`) REFERENCES `tclient` (`id`);
ALTER TABLE `tsales` ADD CONSTRAINT `tsales_ibfk_2` FOREIGN KEY (`paymentId`) REFERENCES `tpayment` (`id`);
ALTER TABLE `tsalesdetails` ADD CONSTRAINT `tsalesdetails_ibfk_1` FOREIGN KEY (`saleID`) REFERENCES `tsales` (`id`);
ALTER TABLE `tsalesdetails` ADD CONSTRAINT `tsalesdetails_ibfk_2` FOREIGN KEY (`productID`) REFERENCES `tproduct` (`id`);
ALTER TABLE `tsaleshistory` ADD CONSTRAINT `tsaleshistory_ibfk_1` FOREIGN KEY (`saleID`) REFERENCES `tsales` (`id`);
ALTER TABLE `tsubtraction` ADD CONSTRAINT `tsubtraction_ibfk_1` FOREIGN KEY (`productId`) REFERENCES `tproduct` (`id`);
ALTER TABLE `image-blog` ADD FOREIGN KEY (`blogId`) REFERENCES `tblog` (`id`);


-- Examples
INSERT INTO `tcategory` (`id`, `name`, `description`, `createdAt`, `updatedAt`) VALUES
('e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'lacteos', 'Descripcion lacteos', '2024-06-26 12:00:00', '2024-06-26 12:00:00');

INSERT INTO `tproduct` (`id`, `categoryId`, `name`, `description`, `quantity`, `status`, `createdAt`, `updatedAt`) VALUES
('29910882-ee95-4d0a-8bf8-4ca190b2b01a', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt Natural', 'Yogurt sin sabor añadido', 50, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('9daee66a-f9fe-4017-9adf-28f368f72035', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Fresa', 'Yogurt con sabor a fresa', 60, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('660f348b-064a-496a-8219-cc1015ac86b3', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt Griego', 'Yogurt estilo griego, más espeso', 30, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('16e69fde-5f27-45d4-a7e7-6397dca5eff7', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Vainilla', 'Yogurt con sabor a vainilla', 45, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('2563f65c-b6b2-4862-b1b0-89f3f5210dd2', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Mango', 'Yogurt con sabor a mango', 25, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('0cebfd3b-cf10-427d-8d2c-bf18108bb608', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Coco', 'Yogurt con sabor a coco', 35, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('ab458d99-cbcb-462d-ae13-9d92288ff0d5', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Durazno', 'Yogurt con sabor a durazno', 40, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('4e3f70ba-5752-41bb-a81d-fe5045012c42', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt con Miel', 'Yogurt endulzado con miel', 50, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('f1a2c374-daa2-447f-93ef-c7a2ff029e03', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt Desnatado', 'Yogurt con bajo contenido de grasa', 55, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('85a8aef4-75b9-4171-8c94-d4e21fe02a11', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt Orgánico', 'Yogurt hecho con ingredientes orgánicos', 20, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('a9315e9b-de9c-4fd4-97be-08a76c0de17f', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Kefir', 'Bebida fermentada similar al yogurt', 30, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('f41a79fd-ae3b-41d0-8b22-de145ba9989c', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Plátano', 'Yogurt con sabor a plátano', 35, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('8dedb145-13f2-4ca7-b05a-14949ea6a00c', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Almendra', 'Yogurt hecho con leche de almendra', 20, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('25e07510-e3a4-444a-90b4-17f6542cc298', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Soya', 'Yogurt hecho con leche de soya', 25, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('da8f0cbb-7137-41b7-a7dd-c341cddc231f', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Frambuesa', 'Yogurt con sabor a frambuesa', 45, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('50dbb5bc-32b0-45ed-b73c-60c65a96941b', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Arándano', 'Yogurt con sabor a arándano', 50, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('9532f5e4-f2a3-4ac5-bea5-a42ef6d173d6', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Piña', 'Yogurt con sabor a piña', 30, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('30b7e69e-2ac2-4647-b6b4-99d70045ad0a', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Limón', 'Yogurt con sabor a limón', 25, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('7a217b6c-6956-4d71-8eb4-143cc6fb3ce7', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt con Avena', 'Yogurt con avena añadida', 40, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00'),
('41a7cf48-cf06-42e7-b408-89feae0fdc46', 'e44f8f10-ae02-4ddd-9c11-0257efceabc2', 'Yogurt de Chocolate', 'Yogurt con sabor a chocolate', 30, 1, '2024-06-26 12:00:00', '2024-06-26 12:00:00');

INSERT INTO `image-product` (`id`, `productId`, `url`) VALUES
('2378bdcc-fae2-4063-a6c0-9012a7255071', 'a9315e9b-de9c-4fd4-97be-08a76c0de17f', 'http://example.com/image1.jpg'),
('23e61e0f-0298-496c-8dfd-b1d311a3ed3a', '41a7cf48-cf06-42e7-b408-89feae0fdc46', 'http://example.com/image2.jpg');


SELECT p.`id`, p.`name`, p.description 
FROM `tproduct` AS p
ORDER BY p.`name`
LIMIT 5 OFFSET 3;

SELECT p.`id`, p.`name`
FROM `tproduct` AS p
WHERE p.`id` > 5
ORDER BY p.`name`
LIMIT 3;

SELECT p.`id`, p.`name`, p.`createdAt`
FROM `tcategory` AS p
ORDER BY p.`name`
LIMIT 5 OFFSET 3;

select * from `tproduct` ;
select * from `image-product` ;
select * from `tcategory`;
SELECT * FROM `tclient`;
select * from `treview`;
SELECT * from `tuser`;
