﻿using DataTransfer.OtherObjects;

namespace Services.Generic
{
    public abstract class SoGeneric<Dto>
    {
        public DtoMessageObject mo { get; set; }
    }
}
