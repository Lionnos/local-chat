﻿namespace Services.ServiceObject
{
    public class SoToken
    {
        public string accessToken { get; set; }
        public string refreshToken { get; set; }
    }
}
