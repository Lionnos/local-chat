﻿using DataTransfer.Objects;
using DataTransfer.OtherObjects;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Services.Helper;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Services.Config
{
    public static class TokenUtils
    {
        public static Task<string> GenerateAccessToken(DtoAuthentication user)
        {
            SymmetricSecurityKey authSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(AppSettings.GetAccessJwtSecret())
            );
            
            List<Claim> claims =
            [
                new Claim("id", user.id),
                new Claim(ClaimTypes.Role, user.role.ToString())
            ];
            
            SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor
            {
                Issuer = AppSettings.GetOriginIssuer(),
                Audience = AppSettings.GetOriginAudience(),
                Expires = DateTime.UtcNow.AddDays(7),
                NotBefore = DateTime.UtcNow,
                SigningCredentials = new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256),
                Subject = new ClaimsIdentity(claims)
            };

            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken token = tokenHandler.CreateToken(tokenDescriptor);
            return Task.FromResult(tokenHandler.WriteToken(token));
        }

        public static Task<string>  GenerateRefreshToken(DtoAuthentication user)
        {
            SymmetricSecurityKey authSigningKey = new SymmetricSecurityKey(
                Encoding.UTF8.GetBytes(AppSettings.GetRefreshJwtSecret())
            );
            
            List<Claim> claims =
            [
                new Claim("id", user.id),
                new Claim("username", user.username),
                new Claim("status", user.status.ToString()),
                new Claim(ClaimTypes.Role, user.role.ToString())
            ];
            
            SecurityTokenDescriptor tokenDescriptor = new SecurityTokenDescriptor
            {
                Issuer = AppSettings.GetOriginIssuer(),
                Audience = AppSettings.GetOriginAudience(),
                Expires = DateTime.UtcNow.AddDays(7),
                NotBefore = DateTime.UtcNow,
                SigningCredentials = new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256),
                Subject = new ClaimsIdentity(claims)
            };

            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken token = tokenHandler.CreateToken(tokenDescriptor);
            return Task.FromResult(tokenHandler.WriteToken(token));
        }

        public static async Task<TokenResponse> GenerateAccessTokenFromRefreshToken(string refreshToken, string secret)
        {
            try
            {
                ClaimsPrincipal primary = await ValidateToken(refreshToken, secret);
                if (primary == null)
                {
                    return new TokenResponse { Success = false, ErrorMessage = "Invalid refresh token" };
                }

                Claim userClaim = primary.Claims.FirstOrDefault(c => c.Type == "id");
                if (userClaim == null)
                {
                    return new TokenResponse { Success = false, ErrorMessage = "Invalid refresh token" };
                }

                DtoAuthentication user = new DtoAuthentication
                {
                    id = userClaim.Value,
                    username = primary.Claims.FirstOrDefault(c => c.Type == "username")?.Value,
                    role = (Hierarchy) Enum.Parse(typeof(Hierarchy), primary.Claims.FirstOrDefault(c => c.Type == ClaimTypes.Role)?.Value)
                };

                String accessToken = await GenerateAccessToken(user);
                return new TokenResponse { Success = true, AccessToken = accessToken };
            }
            catch (SecurityTokenException ex)
            {
                return new TokenResponse { Success = false, ErrorMessage = ex.Message };
            }
        }

        private static Task<ClaimsPrincipal> ValidateToken(string token, string secret)
        {
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            byte[] key = Encoding.ASCII.GetBytes(secret);
            TokenValidationParameters validationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateIssuer = true,
                ValidateAudience = true,
                ValidIssuer = AppSettings.GetOriginIssuer(),
                ValidAudience = AppSettings.GetOriginAudience(),
                ClockSkew = TimeSpan.Zero
            };
            try
            {
                ClaimsPrincipal primary = tokenHandler.ValidateToken(
                    token,
                    validationParameters,
                    out SecurityToken validatedToken
                );
                return Task.FromResult(
                    validatedToken is JwtSecurityToken jwtToken && jwtToken.Header.Alg.Equals(
                        SecurityAlgorithms.HmacSha256, StringComparison.InvariantCultureIgnoreCase)
                        ? primary
                        : null
                );
            }
            catch
            {
                return null;
            }
        }

        public static string GetUserIdFromAccessToken(string accessToken)
        {
            String token = accessToken.Replace("Bearer ", "");
            JwtSecurityTokenHandler tokenHandler = new JwtSecurityTokenHandler();
            JwtSecurityToken jwtToken = tokenHandler.ReadToken(token) as JwtSecurityToken;
            Claim accessClaim = jwtToken?.Claims.FirstOrDefault(claim => claim.Type == "id");

            if (accessClaim != null)
            {
                return accessClaim.Value;
            }
            else
            {
                return null; 
            }
        }
    }
}

