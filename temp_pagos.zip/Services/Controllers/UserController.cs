﻿using Business.Business.User;
using DataTransfer.OtherObjects;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.Config;
using Services.EmailService;
using Services.Generic;
using Services.Helper;
using Services.ServiceObject;

namespace Services.Controllers
{
    public class UserController : ControllerGeneric<BusinessUser, SoUser>
    {
        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public ActionResult<SoUser> Register([FromBody] SoUser so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoUser, new string[]
                {
                    "userName",
                    "password",
                    "firstName",
                    "lastName",
                    "email",
                    "dni",
                    "ruc",
                    "address",
                    "workArea",
                    "workDay",
                    "phoneNumber",
                    "contractStartDate",
                    "dateOfResignation"
                });
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                var email = so.dtoUser.email;
                string tokenConfirm = EmailServices.GenerateEmailConfirmationToken(email);
                var confirmationLink = Url.Action("ConfirmEmail", "User", new { tokenConfirm }, protocol: HttpContext.Request.Scheme);

                EmailServices.SendEmail(email, "Confirma tu correo", "ConfirmEmailTemplate",
                    new Dictionary<string, string> { { "ConfirmationLink", confirmationLink } });
                (_so.mo, so.dtoUser) = _business.Register(so.dtoUser);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }
            
            return _so;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public ActionResult<SoUser> ConfirmEmail([FromBody] SoEmailToken so)
        {
            try
            {              
                var email = EmailServices.ValidateEmailConfirmationToken(so.tokenConfirm);
                if (email == null)
                {
                    _so.mo = new();
                    _so.mo.AddMessage("Token inválido o expirado.");
                    _so.mo.Error();
                    return _so;  
                }

                _so.mo = _business.ConfirmEmail(email);

                if (_so.mo.ExsistsMessage())
                {
                    return _so;  
                }

                return _so; 
            }
            catch (Exception ex)
            {
                _so.mo.AddMessage(ex.Message);
                _so.mo.Exception();
            }
            
            return _so;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public ActionResult<SoUser> SendEmailRecoveryPassword([FromBody] SoUser so) 
        {
            try
            {
                _so.mo = _business.GetByEmail(so.dtoUser.email);
                if (_so.mo.type == "error")
                {
                    return _so;
                }
                string tokenRecovery = EmailServices.GenerateEmailConfirmationToken(so.dtoUser.email);
                var confirmationLink = Url.Action("RecoveryPassword", "User", new { tokenRecovery }, protocol: HttpContext.Request.Scheme);
                
                EmailServices.SendEmail(so.dtoUser.email, "Recupera tu Contraseña", "ResetPasswordTemplate",
                    new Dictionary<string, string> { { "ResetLink", confirmationLink } } );
                _so.mo.AddMessage("Correo electrónico encontrado. Se ha enviado un correo para recuperar la contraseña.");
                _so.mo.Success();
            }
            catch (Exception ex)
            {
                _so.mo.AddMessage(ex.Message);
                _so.mo.Exception();
            }
            
            return _so;
        }

        [AllowAnonymous]
        [HttpPatch]
        [Route("[action]")]
        public ActionResult<SoUser> RecoveryPassword([FromBody] SoEmailToken so)
        {
            try
            {
                var email = EmailServices.ValidateEmailConfirmationToken(so.tokenRecovery);
                if (email == null)
                {
                    _so.mo = new();
                    _so.mo.AddMessage("Token inválido o expirado.");
                    _so.mo.Error();
                    return _so;
                }

                so.dtoRecovery.email = email;
                _so.mo = ValidatePartDto(so.dtoRecovery, new string[] {
                    "email",
                    "newPassword"
                });

                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }

                _so.mo = _business.ChangePassword(so.dtoRecovery);
                _so.mo.AddMessage("Contraseña actualizada con éxito.");
                _so.mo.Success();
            }
            catch (Exception ex)
            {
                _so.mo.AddMessage(ex.Message);
                _so.mo.Exception();
            }

            return _so;
        }
        
        [Authorize]
        [HttpGet]
        [Route("[action]")]
        public ActionResult<SoUser> MyProfile()
        {
            var user = User.Claims.FirstOrDefault();
            var accessToken = Request.Headers["Authorization"].ToString();
            var userIdString = TokenUtils.GetUserIdFromAccessToken(accessToken);
            var userId = new Guid(userIdString);
            (_so.mo, _so.dtoUser) = _business.MyProfile(userId);
            
            return _so;
        }
    }
}
