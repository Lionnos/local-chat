using Business.Business.Client;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.Config;
using Services.Generic;
using Services.ServiceObject;

namespace Services.Controllers
{
    public class ClientController : ControllerGeneric<BusinessClient, SoClient>
    {
        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public ActionResult<SoClient> Register([FromBody] SoClient so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoClient, new string[]
                {
                    "firstName",
                    "lastName",
                    "username",
                    "password",
                    "email",
                    "documentType",
                    "documentNumber",
                    "phoneNumber"
                });
                
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                
                (_so.mo, so.dtoClient) = _business.Register(so.dtoClient);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }

            return _so;
        }
    }
}
