using Business.Business.Review;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.Generic;
using Services.ServiceObject;

namespace Services.Controllers
{
    public class ReviewController : ControllerGeneric<BusinessReview, SoReview>
    {
        [Authorize(Roles="Logged")]
        [HttpPost]
        [Route("[action]")]
        public ActionResult<SoReview> Insert(SoReview so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoReview, new string[]
                {
                    "productId",
                    "clientId",
                    "rating",
                    "reviewText"
                });
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                _so.mo = _business.Insert(so.dtoReview);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }

            return _so;
        }
        
        [AllowAnonymous]        
        [HttpGet]
        [Route("[action]")]
        public ActionResult<SoReview> GetById(Guid id)
        {
            (_so.mo, _so.dtoReview) = _business.GetById(id);
            return _so;
        }

        [AllowAnonymous]
        [HttpGet]
        [Route("[action]")]
        public ActionResult<SoReview> GetWithPagination(int pageNumber, int pageSize)
        {
            (_so.mo, _so.ListDtoReviews, _so.Pagination) = _business.GetWithPagination(pageNumber, pageSize);
            return _so;
        }
        
        [Authorize(Roles="Logged")]
        [HttpPut]
        [Route("[action]")]
        public ActionResult<SoReview> Update(SoReview so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoReview, new string[] {
                    "id",
                    "productId",
                    "clientId",
                    "rating",
                    "reviewText"
                });
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                _so.mo = _business.Update(so.dtoReview);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }
            
            return _so;
        }


        [Authorize(Roles="Logged")]
        [HttpDelete]
        [Route("[action]")]
        public ActionResult<SoReview> Delete(Guid id)
        {
            _so.mo = _business.Delete(id);
            return _so;
        }
    }
}
