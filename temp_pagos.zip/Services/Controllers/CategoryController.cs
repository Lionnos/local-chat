using Business.Business.Blog;
using Business.Business.Category;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.Generic;
using Services.ServiceObject;

namespace Services.Controllers
{
    public class CategoryController : ControllerGeneric<BusinessCategory, SoCategory>
    {
        [Authorize(Roles="Manager,Admin")]
        [HttpPost]
        [Route("[action]")]
        public ActionResult<SoCategory> Insert(SoCategory so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoCategory, new string[] {
                    "name",
                    "description",
                });
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                _so.mo = _business.Insert(so.dtoCategory);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }
            return _so;
        }

        [Authorize(Roles="Manager,Admin")]
        [HttpGet]
        [Route("[action]")]
        public ActionResult<SoCategory> GetById(Guid id)
        {
            (_so.mo, _so.dtoCategory) = _business.GetById(id);
            return _so;
        }

        [Authorize(Roles="Manager,Admin")]
        [HttpGet]
        [Route("[action]")]
        public ActionResult<SoCategory> GetWithPagination(int pageNumber, int pageSize)
        {
            (_so.mo, _so.listDtoCategory, _so.Pagination) = _business.GetWithPagination(pageNumber, pageSize);
            return _so;
        }

        [Authorize(Roles="Manager,Admin")]
        [HttpPut]
        [Route("[action]")]
        public ActionResult<SoCategory> Update(SoCategory so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoCategory, new string[] {
                    "id",
                    "name",
                    "description",
                });
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                _so.mo = _business.Update(so.dtoCategory);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }
            return _so;
        }

        [Authorize(Roles="Admin")]
        [HttpDelete]
        [Route("[action]")]
        public ActionResult<SoCategory> Delete(Guid id)
        {
            _so.mo = _business.Delete(id);
            return _so;
        }
    }
}
