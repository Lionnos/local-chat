﻿using Business.Business.Product;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.Config;
using Services.Generic;
using Services.ServiceObject;

namespace Services.Controllers
{
    public class ProductController : ControllerGeneric<BusinessProduct, SoProduct>
    {
        [Authorize(Roles="Manager,Admin")]
        [HttpPost]
        [Route("[action]")]
        public ActionResult<SoProduct> Insert(SoProduct so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoProduct, new string[] {
                    "id",
                    "categoryId",
                    "name",
                    "description",
                    "quantity",
                    "images.id",
                    "images.url"
                });
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                _so.mo = _business.Insert(so.dtoProduct);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }
            
            return _so;
        }
        
        [AllowAnonymous]
        [HttpGet]
        [Route("[action]")]
        public async Task<ActionResult<SoProduct>> GetWithOffsetPagination(int pageNumber, int pageSize)
        {
            (_so.mo, _so.listDtoProduct, _so.Pagination) = await _business.GetWithOffsetPagination(pageNumber, pageSize);
            return _so;
        }

        [AllowAnonymous]
        [HttpGet]
        [Route("[action]")]
        public ActionResult<SoProduct> GetProductById(Guid id)
        {
            (_so.mo, _so.dtoProduct) = _business.GetProductById(id);
            return _so;
        }

        [Authorize(Roles="Manager,Admin")]
        [HttpDelete]
        [Route("[action]")]
        public ActionResult<SoProduct> Delete(Guid id, string password)
        {
            string accessToken = Request.Headers["Authorization"].ToString();
            string userIdString = TokenUtils.GetUserIdFromAccessToken(accessToken);

            if (userIdString != null)
            {
                Guid userId = new Guid(userIdString);
                _so.mo = _business.Delete(id, userId, password);
            }
            else
            {
                _so.mo.listMessage.Add("Ocurrió un error.");
                _so.mo.Error();
            }
            return _so;
        }

        [Authorize(Roles="Manager,Admin")]
        [HttpPut]
        [Route("[action]")]
        public ActionResult<SoProduct> UpdateOnlyProduct(SoProduct so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoProduct, new string[] {
                    "id",
                    "categoryId",
                    "name",
                    "description",
                    "quantity",
                    "status"
                });
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                _so.mo = _business.Update(so.dtoProduct);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }
            return _so;
        }

        [Authorize(Roles="Manager,Admin")]
        [HttpPut]
        [Route("[action]")]
        public ActionResult<SoProduct> UpdateOnImages(SoProduct so)
        {
            try
            {
                _so.mo = ValidatePartDto(so.dtoProduct, new string[] {
                    "id",
                    "categoryId",
                    "name",
                    "description",
                    "quantity",
                    "status",
                    "images.id",
                    "images.url"
                });
                if (_so.mo.ExsistsMessage())
                {
                    return _so;
                }
                _so.mo = _business.UpdateOnImages(so.dtoProduct);
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }
            return _so;
        }
    }
}
