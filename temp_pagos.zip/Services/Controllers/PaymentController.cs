using Business.Niubiz;
using Microsoft.AspNetCore.Mvc;

namespace Services.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PaymentController(NiubizService niubizService) : ControllerBase
    {
        [HttpGet("create-session")]
        public async Task<IActionResult> CreateSession()
        {
            try
            {
                string sessionResult = await niubizService.CreateSession();
                return Ok(new { SessionKey = sessionResult });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "Error", error = ex.Message });
            }
        }
    }
}
