using Business.Business.Authentication;
using DataTransfer.OtherObjects;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Services.Config;
using Services.Generic;
using Services.Helper;
using Services.ServiceObject;

namespace Services.Controllers
{
    public class UserAuthenticationController : ControllerGeneric<BusinessAuthentication, SoAuthentication>
    {
        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public async Task<ActionResult<SoAuthentication>> Login([FromBody] SoAuthentication so)
        {
            try
            {
                (_so.mo, _so.dtoAuthentication) = _business.SearchByUser(so.dtoAuthentication.username);
                if (_so.dtoAuthentication != null &&
                    BCrypt.Net.BCrypt.Verify(so.dtoAuthentication.password, _so.dtoAuthentication.password))
                {
                    if (_so.dtoAuthentication.status == false)
                    {
                        _so.mo.listMessage.Add("Cuenta no confirmada. Por favor, confirma tu correo electrónico.");
                        _so.mo.Error();
                        _so.dtoAuthentication = null;
                        return Unauthorized(_so);
                    }

                    _so.dtoAuthentication.password = null;
                    _so.accessToken = await TokenUtils.GenerateAccessToken(_so.dtoAuthentication);
                    _so.refreshToken = await TokenUtils.GenerateRefreshToken(_so.dtoAuthentication);
                    _so.mo.listMessage.Add("Bienvenido al sistema.");
                    _so.mo.Success();
                }
                else
                {
                    _so.dtoAuthentication = null;
                    _so.mo.listMessage.Add("Usuario o contraseña incorrecta.");
                    _so.mo.Error();
                    return _so;
                }
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }

            return _so;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public async Task<ActionResult<SoAuthentication>> RefreshToken([FromBody] SoToken so)
        {
            TokenResponse tokenResponse = await TokenUtils.GenerateAccessTokenFromRefreshToken(
                so.refreshToken,
                AppSettings.GetRefreshJwtSecret()
            );
            if (!tokenResponse.Success)
            {
                return Unauthorized(new { message = tokenResponse.ErrorMessage });
            }

            SoToken response = new()
            {
                accessToken = tokenResponse.AccessToken,
                refreshToken = so.refreshToken
            };

            return Ok(response);
        }
    }

    public class ClientAuthenticationController : ControllerGeneric<BusinessAuthentication, SoAuthentication>
    {
        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public async Task<ActionResult<SoAuthentication>> Login([FromBody] SoAuthentication so)
        {
            try
            {
                if (!string.IsNullOrEmpty(so.dtoAuthentication.username) && !string.IsNullOrEmpty(so.dtoAuthentication.password))
                {
                    if (so.dtoAuthentication.username.Contains("@") && 
                        (so.dtoAuthentication.username.EndsWith(".com") || 
                         so.dtoAuthentication.username.EndsWith(".net") ||
                         so.dtoAuthentication.username.EndsWith(".pe")) //develop
                        )
                    {
                        (_so.mo, _so.dtoAuthentication) = _business.GetByEmailClient(so.dtoAuthentication.username);
                    }
                    else
                    {
                        (_so.mo, _so.dtoAuthentication) = _business.GetByUsernameClient(so.dtoAuthentication.username);
                    }
                }
                else
                {
                    return BadRequest("Proporcione su usuario o correo electrónico...");
                }
                
                if (_so.dtoAuthentication != null &&
                    BCrypt.Net.BCrypt.Verify(so.dtoAuthentication.password, _so.dtoAuthentication.password))
                {
                    if (_so.dtoAuthentication.status == false)
                    {
                        _so.mo.listMessage.Add("Cuenta no confirmada. Por favor, confirma tu correo electrónico.");
                        _so.mo.Error();
                        _so.dtoAuthentication = null;
                        return Unauthorized(_so);
                    }

                    _so.dtoAuthentication.password = null;
                    _so.accessToken = await TokenUtils.GenerateAccessToken(_so.dtoAuthentication);
                    _so.refreshToken = await TokenUtils.GenerateRefreshToken(_so.dtoAuthentication);
                    _so.mo.listMessage.Add("Bienvenido " + so.dtoAuthentication.username + "!");
                    _so.mo.Success();
                }
                else
                {
                    _so.dtoAuthentication = null;
                    _so.mo.listMessage.Add("Usuario o contraseña incorrecta.");
                    _so.mo.Error();
                    return _so;
                }
            }
            catch (Exception ex)
            {
                _so.mo.listMessage.Add(ex.Message);
                _so.mo.Exception();
            }

            return _so;
        }

        [AllowAnonymous]
        [HttpPost]
        [Route("[action]")]
        public async Task<ActionResult<SoAuthentication>> RefreshToken([FromBody] SoToken so)
        {
            TokenResponse tokenResponse = await TokenUtils.GenerateAccessTokenFromRefreshToken(
                so.refreshToken,
                AppSettings.GetRefreshJwtSecret()
            );
            if (!tokenResponse.Success)
            {
                return Unauthorized(new { message = tokenResponse.ErrorMessage });
            }

            SoToken response = new()
            {
                accessToken = tokenResponse.AccessToken,
                refreshToken = so.refreshToken
            };

            return Ok(response);
        }
    }
}