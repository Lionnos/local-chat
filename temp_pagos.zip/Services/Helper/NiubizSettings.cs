using DataTransfer.OtherObjects;

namespace Services.Helper
{
    public class NiubizSettings
    {
        public static DtoNiubizSettings dtoNiubizSettings;

        public static void Init()
        {
            dtoNiubizSettings = new DtoNiubizSettings();

            IConfigurationBuilder builder = new ConfigurationBuilder()
                .SetBasePath(Directory.GetCurrentDirectory())
                .AddJsonFile("appsettings.json");
            IConfigurationRoot configuration = builder.Build();

            dtoNiubizSettings.MerchantId = configuration["Niubiz:MerchantId"];
            dtoNiubizSettings.AccessKey = configuration["Niubiz:AccessKey"];
            dtoNiubizSettings.SecretKey = configuration["Niubiz:SecretKey"];
            dtoNiubizSettings.ApiUrl = configuration["Niubiz:ApiUrl"];
        }

        public static string GetMerchantId()
        {
            return dtoNiubizSettings.MerchantId;
        }
        
        public static string GetAccessKey()
        {
            return dtoNiubizSettings.AccessKey;
        }

        public static string GetSecretKey()
        {
            return dtoNiubizSettings.SecretKey;
        }

        public static string GetApiUrl()
        {
            return dtoNiubizSettings.ApiUrl;
        }
    }
}

