using DataTransfer.Objects;
using Services.Generic;

namespace Services.ServiceObject
{
    public class SoClient : SoGeneric<DtoClient>
    {
        public DtoClient dtoClient { get; set; }
        public string accessToken { get; set; }
        public string refreshToken { get; set; }
    }
}
