﻿using DataTransfer.Objects;
using DataTransfer.OtherObjects;
using Services.Generic;

namespace Services.ServiceObject
{
    public class SoProduct : SoGeneric<DtoProduct>
    {
        public DtoProduct dtoProduct { get; set; }
        public ICollection<DtoProduct> listDtoProduct { get; set; }
        public Pagination Pagination { get; set; }
    }
}
