using DataTransfer.Objects;
using DataTransfer.OtherObjects;
using Services.Generic;

namespace Services.ServiceObject
{
    public class SoReview : SoGeneric<DtoReview>
    {
        public DtoReview dtoReview { get; set; }
        public ICollection<DtoReview> ListDtoReviews { get; set; }
        public Pagination Pagination { get; set; }
    }
}
