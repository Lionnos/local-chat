using DataTransfer.Objects;
using DataTransfer.OtherObjects;
using Services.Generic;

namespace Services.ServiceObject
{
    public class SoCategory : SoGeneric<DtoCategory>
    {
        public DtoCategory dtoCategory { set; get; }
        public ICollection<DtoCategory> listDtoCategory { get; set; }
        public Pagination Pagination { get; set; }
    }
}
