﻿using DataTransfer.Objects;
using Services.Generic;

namespace Services.ServiceObject
{
    public class SoEmailToken :SoGeneric<DtoRecovery>
    {
        public string tokenRecovery {  get; set; }
        public string tokenConfirm { get; set; }
        public DtoRecovery dtoRecovery {  get; set; }
    }
}
