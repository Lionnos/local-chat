﻿using DataTransfer.Objects;
using Services.Generic;

namespace Services.ServiceObject
{
    public class SoUser : SoGeneric<DtoUser>
    {
        public DtoUser dtoUser { get; set; }
        public string accessToken { get; set; }
        public string refreshToken { get; set; }
    }
}
