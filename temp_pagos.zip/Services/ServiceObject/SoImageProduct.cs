using DataTransfer.Objects;

namespace Services.ServiceObject
{
    public class SoImageProduct
    {
        public DtoImage_Product dtoImageProduct { get; set; }
    }
}

