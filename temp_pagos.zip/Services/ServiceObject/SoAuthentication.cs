using DataTransfer.Objects;
using Services.Generic;

namespace Services.ServiceObject
{
    public class SoAuthentication : SoGeneric<DtoAuthentication>
    {
        public DtoAuthentication dtoAuthentication { get; set; }
        public string accessToken { get; set; }
        public string refreshToken { get; set; }
    }
}
