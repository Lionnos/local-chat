﻿using MailKit.Net.Smtp;
using Microsoft.IdentityModel.Tokens;
using MimeKit;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Services.EmailService
{
    public static class EmailServices
    {
        private static IConfiguration _configuration;

        public static void Initialize(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private static string GetEmailTemplate(string templateName)
        {
            var path = Path.Combine(Directory.GetCurrentDirectory(), "EmailService", $"{templateName}.html");
            return File.ReadAllText(path);
        }

        private static string PopulateTemplate(string template, Dictionary<string, string> placeholders)
        {
            foreach (var placeholder in placeholders)
            {
                template = template.Replace($"{{{{{placeholder.Key}}}}}", placeholder.Value);
            }
            return template;
        }

        public static string GenerateEmailConfirmationToken(string email)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_configuration["Authentication:Jwt:AccessTokenSecret"]);
            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = new ClaimsIdentity(new[] { new Claim("email", email) }),
                Expires = DateTime.UtcNow.AddMinutes(5),
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var token = tokenHandler.CreateToken(tokenDescriptor);
            return tokenHandler.WriteToken(token);
        }
        public static string ValidateEmailConfirmationToken(string token)
        {
            var tokenHandler = new JwtSecurityTokenHandler();
            var key = Encoding.UTF8.GetBytes(_configuration["Authentication:Jwt:AccessTokenSecret"]);

            try
            {
                tokenHandler.ValidateToken(token, new TokenValidationParameters
                {
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = new SymmetricSecurityKey(key),
                    ValidateIssuer = false,
                    ValidateAudience = false,
                    ClockSkew = TimeSpan.Zero
                }, out SecurityToken validatedToken);

                var jwtToken = (JwtSecurityToken)validatedToken;
                var email = jwtToken.Claims.First(x => x.Type == "email").Value;

                return email;
            }
            catch
            {
                return null;
            }
        }
        public static void SendEmail(string email, string subject, string templateName, Dictionary<string, string> placeholders)
        {
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress("Agroindustrias Mafer", _configuration["Email:Smtp:From"]));
            emailMessage.To.Add(new MailboxAddress("", email));
            emailMessage.Subject = subject;

            var template = GetEmailTemplate(templateName);
            var body = PopulateTemplate(template, placeholders);
            emailMessage.Body = new TextPart("html") { Text = body };

            using var client = new SmtpClient();
            client.Connect(_configuration["Email:Smtp:Host"], int.Parse(_configuration["Email:Smtp:Port"]), true);
            client.Authenticate(_configuration["Email:Smtp:Username"], _configuration["Email:Smtp:Password"]);
            client.Send(emailMessage);
            client.Disconnect(true);
        }
    }
}
