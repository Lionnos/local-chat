﻿namespace DataTransfer.OtherObjects
{
    public class DtoMessageObject
    {
        public List<string> listMessage { get; set; }
        public string type { get; set; }

        public DtoMessageObject()
        {
            listMessage = new List<string>();
            type = "error";
        }

        public bool ExsistsMessage()
        {
            return listMessage.Count > 0;
        }

        public void AddMessage(string message)
        {
            listMessage.Add(message);
        }

        public void Success()
        {
            type = "success";
        }

        public void Warning()
        {
            type = "warning";
        }

        public void Error()
        {
            type = "error";
        }

        public void Exception()
        {
            type = "exception";
        }
    }
}
