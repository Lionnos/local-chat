namespace DataTransfer.OtherObjects
{
    public class DtoNiubizSettings
    {
        public string MerchantId { get; set; }
        public string AccessKey { get; set; }
        public string SecretKey { get; set; }
        public string ApiUrl { get; set; }
    }
}
