﻿namespace DataTransfer.OtherObjects
{
    public class TokenResponse
    {
        public bool Success { get; set; }
        public string AccessToken { get; set; }
        public string ErrorMessage { get; set; }
    }
}
