namespace DataTransfer.OtherObjects
{
    public enum Hierarchy
    {
        Manager = 1,
        Admin = 2,
        Employee = 3,
        Other = 4,
        Logged = 5
    }
}
