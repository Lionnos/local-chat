namespace DataTransfer.Generic
{
    public class DtoGeneric
    {
        public DateTime createdAt { get; set; }
        public DateTime updatedAt { get; set; }
    }
}
