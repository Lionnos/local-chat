namespace DataTransfer.Generic
{
    public class DtoInventory
    {
        public Guid productId {  get; set; }
        public int quantity { get; set; }
        public DateTime changeDate { get; set; }
    }
}
