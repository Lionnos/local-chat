﻿using DataTransfer.Generic;
using DataTransfer.OtherObjects;

namespace DataTransfer.Objects
{
    public class DtoSubtraction : DtoInventory
    {
        public Guid id { get; set; }
    }
}
