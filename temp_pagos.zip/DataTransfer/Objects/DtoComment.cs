using DataTransfer.Generic;

namespace DataTransfer.Objects
{
    public class DtoComment : DtoGeneric
    {
        public Guid id { get; set; }
        public string content { get; set; }
        public Guid blogId { get; set; }
        public Guid clientId { get; set; }
    }
}
