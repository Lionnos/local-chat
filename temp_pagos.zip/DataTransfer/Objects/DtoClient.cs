﻿using DataTransfer.Generic;
using DataTransfer.OtherObjects;

namespace DataTransfer.Objects
{
    public class DtoClient : DtoGeneric
    {
        public Guid id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; } 
        public string email { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string documentType { get; set; }
        public string documentNumber { get; set; }
        public string phoneNumber { get; set; }
        public Hierarchy role { get; set; }
        public bool status { get; set; }
    }
}
