﻿namespace DataTransfer.Objects
{
    public class DtoImage_Product
    {
        public Guid id { get; set; }
        public Guid productId { get; set; }
        public string url { get; set; }
    }
}
