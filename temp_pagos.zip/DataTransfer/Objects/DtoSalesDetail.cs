﻿namespace DataTransfer.Objects
{
    public class DtoSalesDetail
    {
        public Guid id { get; set; }
        public Guid productId { get; set; }
        public Guid saleId { get; set; }
        public int quantity { get; set; }
        public decimal unitPrice { get; set; }
        public decimal subTotalPrice { get; set; }
    }
}
