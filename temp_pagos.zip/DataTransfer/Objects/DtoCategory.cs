﻿using DataTransfer.Generic;

namespace DataTransfer.Objects
{
    public class DtoCategory : DtoGeneric
    {
        public Guid id { get; set; }
        public string name { get; set; }
        public string description { get; set; }
    }
}
