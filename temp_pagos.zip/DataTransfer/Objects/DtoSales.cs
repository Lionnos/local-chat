﻿namespace DataTransfer.Objects
{
    public class DtoSales
    {
        public Guid id { get; set; }
        public Guid clientId { get; set; }
        public Guid paymentId { get; set; }
        public decimal totalPrice { get; set; }
        public DateTime date { get; set; }
    }
}
