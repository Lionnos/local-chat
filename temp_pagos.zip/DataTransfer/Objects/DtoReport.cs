﻿namespace DataTransfer.Objects
{
    public class DtoReport
    {
        public Guid id { get; set; }
        public string reportType { get; set; }
        public DateTime generatedAt { get; set; }
        public string reportData { get; set; }
    }
}
