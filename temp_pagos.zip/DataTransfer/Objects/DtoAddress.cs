﻿using DataTransfer.Generic;

namespace DataTransfer.Objects
{
    public class DtoAddress : DtoGeneric
    {
        public Guid id { get; set; }
        public Guid clientId { get; set; }
        public string department { get; set; }
        public string province { get; set; }
        public string district { get; set; }
        public string address { get; set; }
        public string reference { get; set; }
        public string postalCode { get; set; }
    }
}
