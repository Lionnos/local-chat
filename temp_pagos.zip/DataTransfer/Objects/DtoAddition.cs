﻿using DataTransfer.Generic;
using DataTransfer.OtherObjects;

namespace DataTransfer.Objects
{
    public class DtoAddition : DtoInventory
    {
        public Guid id { get; set; }
    }
}
