namespace DataTransfer.Objects
{
    public class DtoReaction
    {
        public Guid id { get; set; }
        public byte type { get; set; }
        public DateTime createAt { get; set; }
        public Guid blogId { get; set; }
        public Guid clientId { get; set; }   
    }
}
