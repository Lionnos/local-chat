﻿namespace DataTransfer.Objects
{
    public class DtoPayment
    {
        public Guid id { get; set; }
        public Guid clientId { get; set; }
        public string paymentMethod { get; set; }
        public string paymentStatus { get; set; }
        public DateTime paymentDate { get; set; }
        public decimal amount { get; set; }        
    }
}
