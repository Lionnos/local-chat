﻿namespace DataTransfer.Objects
{
    public class DtoSalesHistory
    {
        public Guid id { get; set; }
        public Guid saleId { get; set; }
        public string status { get; set; }
        public DateTime changedAt { get; set; }        
    }
}
