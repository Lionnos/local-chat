﻿namespace DataTransfer.Objects
{
    public class DtoReview
    {
        public Guid id { get; set; }
        public Guid productId { get; set; }
        public Guid clientId { get; set; }
        public int rating { get; set; }
        public string reviewText { get; set; }
        public DateTime reviewDate {  get; set; }
    }
}
