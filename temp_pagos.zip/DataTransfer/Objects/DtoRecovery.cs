﻿namespace DataTransfer.Objects
{
    public class DtoRecovery
    {
        public string email { get; set; }
        public string newPassword { get; set; }
    }
}
