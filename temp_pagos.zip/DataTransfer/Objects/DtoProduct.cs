﻿using DataTransfer.Generic;

namespace DataTransfer.Objects
{
    public class DtoProduct : DtoGeneric
    {
        public Guid id { get; set; }
        public Guid categoryId { get; set; } 
        public string name { get; set; }
        public string description {  get; set; } 
        public int quantity { get; set; }
        public bool status { get; set; }
        
        #region Childs
        public ICollection<DtoImage_Product> Images { get; set; } = new List<DtoImage_Product>();
        public ICollection<DtoReview> Reviews { get; set; } = new List<DtoReview>();
        #endregion
    }
}
