using DataTransfer.OtherObjects;

namespace DataTransfer.Objects
{
    public class DtoAuthentication
    {
        public string id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public Hierarchy role { get; set; }
        public bool? status { get; set; }
    }
}
