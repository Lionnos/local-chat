﻿namespace DataAccess.Entity
{
    public class Reaction
    {
        public Guid id { get; set; }
        public byte type { get; set; }
        public DateTime createAt { get; set; }
        public Guid blogId { get; set; }
        public Guid clientId { get; set; }
    }
}
