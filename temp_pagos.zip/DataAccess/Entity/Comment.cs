using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DataAccess.Generic;

namespace DataAccess.Entity
{
    [Table("tcomment")]
    public class Comment : EntityGeneric
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public string content { get; set; }
        public Guid blogId { get; set; }
        public Guid clientId { get; set; }
    }
}
