﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DataAccess.Entity
{
    [Table("image-product")]
    public class Image_Product
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public Guid productId { get; set; }
        public string url { get; set; }

        #region Parent
        public Product Product { get; set; } = null!;
        #endregion
    }
}
