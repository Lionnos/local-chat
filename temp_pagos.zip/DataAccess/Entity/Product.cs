﻿using DataAccess.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entity
{
    [Table("tProduct")]
    public class Product : EntityGeneric
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public Guid categoryId { get; set; } 
        public string name { get; set; }
        public string description {  get; set; } 
        public int quantity { get; set; }
        public bool status { get; set; }

        #region Childs
        public ICollection<Image_Product> ChildImageProducts { get; set; } = new List<Image_Product>();
        public ICollection<Review> ChidReviews { get; set; } = new List<Review>();
        #endregion
    }
}
