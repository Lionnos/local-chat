﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace DataAccess.Entity
{
    [Table("tsaleshistory")]
    public class SalesHistory
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public Guid saleId { get; set; }
        public string status { get; set; }
        public DateTime changedAt { get; set; }
    }
}
