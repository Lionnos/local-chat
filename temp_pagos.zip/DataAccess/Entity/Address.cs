﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using DataAccess.Generic;

namespace DataAccess.Entity
{
    [Table("taddress")]
    public class Address : EntityGeneric
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public Guid clientId { get; set; }
        public string department { get; set; }
        public string province { get; set; }
        public string district { get; set; }
        public string address { get; set; }
        public string reference { get; set; }
        public string postalCode { get; set; }

        #region parents
        public Client Client { get; set; }
        #endregion

        #region childs
        #endregion
    }
}
