using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entity
{
    [Table("torderstatus")]
    public class OrderStatus
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public Guid saleId { get; set; }
        public string status { get; set; }
        public DateTime statusChangedAt { get; set; }
    }
}

