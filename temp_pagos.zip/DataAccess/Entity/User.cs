﻿using DataAccess.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace DataAccess.Entity
{
    [Table("tuser")]
    public class User : EntityGeneric
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string email { get; set; }
        public string dni { get; set; }
        public string ruc { get; set; }
        public string address { get; set; }
        public string workArea { get; set; }
        public string workDay { get; set; }
        public string phoneNumber { get; set; }
        public Hierarchy role { get; set; }
        public bool status { get; set; }
        public DateTime contractStartDate { get; set; }
        public DateTime? dateOfResignation { get; set; }
        public DateTime createdAt { get; set; }
        public DateTime updatedAt { get; set; }
        public Guid? createdBy { get; set; }
        public Guid? updatedBy { get; set; }
    }
}
