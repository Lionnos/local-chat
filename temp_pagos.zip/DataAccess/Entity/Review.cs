﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entity
{
    [Table("treview")]
    public class Review
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public Guid productId { get; set; }
        public Guid clientId { get; set; }
        public int rating { get; set; }
        public string reviewText { get; set; }
        public DateTime reviewDate {  get; set; }
        
        #region Parent
        public Product ParentProduct { get; set; } = null!;
        public Client ParentClient { get; set; } = null!;
        #endregion
    }
}
