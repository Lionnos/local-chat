﻿using DataAccess.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace DataAccess.Entity
{
    [Table("tclient")]
    public class Client : EntityGeneric
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; } 
        public string email { get; set; }
        public string username { get; set; }
        public string password { get; set; }
        public string documentType { get; set; }
        public string documentNumber { get; set; }
        public string phoneNumber { get; set; }
        public Hierarchy role { get; set; }
        public bool status { get; set; }

        #region parents
        #endregion

        #region childs
        public Address childAddress { get; set; } = null!;
        public ICollection<Review> ChildReviews { get; set; } = new List<Review>();
        public ICollection<Sales> childSales { get; set; } = new List<Sales>();
        #endregion
    }
}
