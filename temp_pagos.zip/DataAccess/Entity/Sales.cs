﻿using DataAccess.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entity
{
    [Table("tsales")]
    public class Sales
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public Guid clientId { get; set; }
        public Guid paymentId { get; set; }
        public decimal totalPrice { get; set; }
        public DateTime date { get; set; }

    }
}
