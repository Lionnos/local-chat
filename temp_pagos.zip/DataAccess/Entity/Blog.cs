using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using DataAccess.Generic;

namespace DataAccess.Entity
{
    [Table("tblog")]
    public class Blog : EntityGeneric
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public string title { get; set; }
        public string subtitle { get; set; }
        public string content { get; set; }
        public bool status { get; set; }
        public Guid userId { get; set; }
    }
}
