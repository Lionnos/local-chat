using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DataAccess.Entity
{
    [Table("treport")]
    public class Report
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Guid id { get; set; }
        public string reportType { get; set; }
        public DateTime generatedAt { get; set; }
        public string reportData { get; set; }
    }
}
