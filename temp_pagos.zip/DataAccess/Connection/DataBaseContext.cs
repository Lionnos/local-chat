﻿using DataAccess.Entity;
using DataTransfer.OtherObjects;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Connection
{
    public class DataBaseContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<Client> Clients { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Addition> Additions { get; set; }
        public DbSet<Subtraction> Subtractions { get; set; }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<Image_Product> ImageProducts { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<Review> Reviews { get; set; }
        public DbSet<Sales> Sales { get; set; }
        public DbSet<Blog> Blogs { get; set; }
        public DbSet<Comment> Comments { get; set; }
        public DbSet<Reaction> Reactions { get; set; }
        public DbSet<Report> Reports { get; set; }
        public DbSet<SalesDetail> SalesDetails { get; set; }
        public DbSet<SalesHistory> SalesHistories { get; set; }


        public DataBaseContext()
        {
            AutoMapper.start();
        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().ToTable("tuser");
            modelBuilder.Entity<Client>().ToTable("tclient");
            modelBuilder.Entity<Product>().ToTable("tproduct");
            modelBuilder.Entity<Category>().ToTable("tcategory");
            modelBuilder.Entity<Addition>().ToTable("taddition");
            modelBuilder.Entity<Subtraction>().ToTable("tsubtraction");
            modelBuilder.Entity<Address>().ToTable("taddress");
            modelBuilder.Entity<Image_Product>().ToTable("image-product");
            modelBuilder.Entity<Payment>().ToTable("tpayment");
            modelBuilder.Entity<Review>().ToTable("treview");
            modelBuilder.Entity<Sales>().ToTable("tsales");
            modelBuilder.Entity<SalesDetail>().ToTable("tsalesdetails");
            modelBuilder.Entity<SalesHistory>().ToTable("tsaleshistory");
            modelBuilder.Entity<Blog>().ToTable("tblog");
            modelBuilder.Entity<Comment>().ToTable("tcomment");
            modelBuilder.Entity<Image_Blog>().ToTable("image-blog");
            modelBuilder.Entity<OrderStatus>().ToTable("torderstatus");
            modelBuilder.Entity<Reaction>().ToTable("treactions");
            modelBuilder.Entity<Report>().ToTable("treport");

            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.id);
                entity.Property(e => e.role)
                    .IsRequired()
                    .HasConversion(
                        v => v.ToString(),
                        v => (Hierarchy)Enum.Parse(typeof(Hierarchy), v))
                    .HasColumnType("enum('Manager','Admin','Employee','Other')");
            });
            
            modelBuilder.Entity<Client>(entity =>
            {
                entity.HasKey(e => e.id);
                entity.Property(e => e.role)
                    .IsRequired()
                    .HasConversion(
                        v => v.ToString(),
                        v => (Hierarchy)Enum.Parse(typeof(Hierarchy), v))
                    .HasColumnType("enum('Logged')");
            });
            
            modelBuilder.Entity<Client>()
                .HasOne(e => e.childAddress)
                .WithOne(e => e.Client)
                .HasForeignKey<Address>(e => e.clientId)
                .IsRequired();
            /*
            modelBuilder.Entity<Product>()
                .HasMany(e => e.ChidReviews)
                .WithOne(e => e.Product)
                .HasForeignKey(e => e.productId)
                .IsRequired();
            
            modelBuilder.Entity<Product>()
                .HasMany(e => e.ChildImageProducts)
                .WithOne(e => e.Product)
                .HasForeignKey(e => e.productId)
                .IsRequired();
            */
            modelBuilder.Entity<Product>(entity =>
            {
                entity.HasKey(e => e.id);
                entity.HasMany(e => e.ChildImageProducts)
                    .WithOne(e => e.Product)
                    .HasForeignKey(e => e.productId)
                    .IsRequired();
                entity.HasMany(e => e.ChidReviews)
                    .WithOne(e => e.ParentProduct)
                    .HasForeignKey(e => e.productId)
                    .IsRequired();
            });
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            try
            { 
                //string connectionString = "server=localhost;port=5440;user=root;password=ef4bfac7;database=dbapimafer";
                string connectionString = "server=localhost;port=3306;user=root;password=1001mariadb;database=dbapimafer";
               ServerVersion serverVersion = new MySqlServerVersion(new Version(8, 4, 0));
               optionsBuilder.UseMySql(connectionString, serverVersion);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
