﻿namespace DataAccess.Generic
{
    public class EntityGeneric
    {
        public DateTime createdAt { get; set; }
        public DateTime updatedAt { get; set; }
    }
}
