using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QClient
    {
        public int Register(DtoClient dto)
        {
            using DataBaseContext dbc = new();
            dbc.Add(AutoMapper.mapper.Map<Client>(dto));
            return dbc.SaveChanges();
        }

        public DtoClient GetByEmail(string email)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoClient>(dbc.Clients.Where(w => w.email == email).FirstOrDefault());
        }
        
        public DtoClient myProfile(Guid id)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoClient>(dbc.Clients.Find(id));
        }
        
        public DtoClient GetByDocument(string documentNumber)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoClient>(dbc.Clients.Where(w => w.documentNumber == documentNumber).FirstOrDefault());
        }


        public DtoClient GetById(Guid id)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoClient>(dbc.Clients.Find(id));
        }

        public List<DtoClient> GetAll()
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<List<DtoClient>>(dbc.Clients.ToList());
        }

        public int Update(DtoClient dtoClient)
        {
            using DataBaseContext dbc = new();
            Client client = dbc.Clients.Find(dtoClient.id);
            client.firstName = dtoClient.firstName;
            client.lastName = dtoClient.lastName;
            client.email = dtoClient.email;
            client.password = dtoClient.password;
            client.documentType = dtoClient.documentType;
            client.documentNumber = dtoClient.documentNumber;
            client.status = dtoClient.status;
            client.phoneNumber = dtoClient.phoneNumber;

            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();
            Client client = dbc.Clients.Find(id);
            if (client != null)
            {
                dbc.Clients.Remove(client);
                return dbc.SaveChanges();
            }

            return 0;
        }
        
        public DtoClient GetByNumberDocument(string documentNumber)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoClient>(dbc.Clients.FirstOrDefault(w => w.documentNumber == documentNumber));
        }
        
        public DtoClient GetByUsername(string username){
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoClient>(dbc.Clients.FirstOrDefault(w => w.username == username));
        }
    }
}
