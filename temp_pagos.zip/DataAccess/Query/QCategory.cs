using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Query
{
    public class QCategory
    {
        public int Insert (DtoCategory dtoCategory)
        {
            using DataBaseContext dbc = new();

            dbc.Categories.Add(AutoMapper.mapper.Map<Category>(dtoCategory));

            return dbc.SaveChanges();
        }

        public DtoCategory GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoCategory>(dbc.Categories.Find(id));
        }

        public int Update(DtoCategory dtoCategory)
        {
            using DataBaseContext dbc = new();
    
            Category category = dbc.Categories.Find(dtoCategory.id);

            category.name = dtoCategory.name;
            category.description = dtoCategory.description;
            category.updatedAt = dtoCategory.updatedAt;

            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Category category = dbc.Categories.Find(id);

            if (category != null)
            {
                dbc.Categories.Remove(category);
                return dbc.SaveChanges();
            }

            return 0;
        }
        public (ICollection<DtoCategory>, Pagination) GetWithPagination(int pageNumber, int pageSize)
        {
            using DataBaseContext dbc = new();

            int totalRecords = dbc.Categories.Count();
            int totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);

            ICollection<Category> categories = dbc.Categories
                .AsNoTracking()
                .OrderBy(p => p.name)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToList();
    
            ICollection<DtoCategory> dtoCategories = AutoMapper.mapper.Map<ICollection<DtoCategory>>(categories);

            Pagination pagination = new Pagination
            {
                pageNumber = pageNumber,
                pageSize = pageSize,
                totalPages = totalPages,
                totalRecords = totalRecords
            };
    
            return (dtoCategories, pagination);
        }

        public bool ExistByName(string name)
        {
            using DataBaseContext dbc = new();
            return dbc.Categories.Any(w => w.name.Replace(" ", string.Empty) == name.Replace(" ", string.Empty));
        }
        
        public DtoCategory GetByName(string name)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoCategory>(dbc.Categories.FirstOrDefault(w => w.name == name));
        }
    }
}
