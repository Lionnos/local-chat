using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QSubtraction
    {
        public int Insert (DtoSubtraction dtoSubtraction)
        {
            using DataBaseContext dbc = new();

            dbc.Subtractions.Add(AutoMapper.mapper.Map<Subtraction>(dtoSubtraction));

            return dbc.SaveChanges();
        }

        public DtoSubtraction GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoSubtraction>(dbc.Subtractions.Find(id));
        }

        public List<DtoSubtraction> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoSubtraction>>(dbc.Subtractions.ToList());
        }

        public int Update(DtoSubtraction dtoSubtraction)
        {
            using DataBaseContext dbc = new();
    
            Subtraction subtraction = dbc.Subtractions.Find(dtoSubtraction.id);

            subtraction.productId = dtoSubtraction.productId;
            subtraction.quantity = dtoSubtraction.quantity;
            subtraction.changeDate = dtoSubtraction.changeDate;
            
            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Subtraction subtraction = dbc.Subtractions.Find(id);

            if (subtraction != null)
            {
                dbc.Subtractions.Remove(subtraction);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
