using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QAddition
    {
        public int Insert (DtoAddition dtoAddition)
        {
            using DataBaseContext dbc = new();

            dbc.Additions.Add(AutoMapper.mapper.Map<Addition>(dtoAddition));

            return dbc.SaveChanges();
        }

        public DtoAddition GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoAddition>(dbc.Additions.Find(id));
        }

        public List<DtoAddition> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoAddition>>(dbc.Additions.ToList());
        }

        public int Update(DtoAddition dtoAddition)
        {
            using DataBaseContext dbc = new();
    
            Addition addition = dbc.Additions.Find(dtoAddition.id);

            addition.productId = dtoAddition.productId;
            addition.quantity = dtoAddition.quantity;
            addition.changeDate = dtoAddition.changeDate;

            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Addition addition = dbc.Additions.Find(id);

            if (addition != null)
            {
                dbc.Additions.Remove(addition);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
