﻿using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QUser
    {
        public DtoUser myProfile(Guid id){
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoUser>(dbc.Users.Find(id));
        }
        
        public DtoUser GetByUsername(string username){
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoUser>(dbc.Users.Where(w => w.username == username).FirstOrDefault());
        }

        public DtoUser GetByDni(string dni) { 
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoUser>(dbc.Users.Where(w => w.dni == dni).FirstOrDefault());
        }

        public DtoUser GetByEmail(string email){
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoUser>(dbc.Users.Where(w => w.email == email).FirstOrDefault());
        }

        public int Register(DtoUser dto){
            using DataBaseContext dbc = new();
            dbc.Add(AutoMapper.mapper.Map<User>(dto));
            return dbc.SaveChanges();
        }

        public string GetPasswordById(Guid id)
        {
            using DataBaseContext dbc = new();
            User user = dbc.Users.SingleOrDefault(u => u.id == id);
            if (user != null)
            {
                return user.password;
            }
            return null;
        }

        public int Update(DtoUser dto){
            using DataBaseContext dbc = new();
            var user = dbc.Users.Find(dto.id);
            if (user != null)
            {
                user.username = dto.username;
                user.password = dto.password;
                user.firstName = dto.firstName;
                user.lastName = dto.lastName;
                user.email = dto.email;
                user.dni = dto.dni;
                user.ruc = dto.ruc;
                user.status = dto.status;
                user.role = dto.role;
                user.phoneNumber = dto.phoneNumber;
                user.updatedAt = dto.updatedAt;

                dbc.Users.Update(user);
                return dbc.SaveChanges();
            }
            return 0;
        }
    }
}
