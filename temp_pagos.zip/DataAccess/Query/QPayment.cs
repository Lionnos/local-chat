using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QPayment
    {
        public int Insert (DtoPayment dtoPayment)
        {
            using DataBaseContext dbc = new();

            dbc.Payments.Add(AutoMapper.mapper.Map<Payment>(dtoPayment));

            return dbc.SaveChanges();
        }

        public DtoPayment GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoPayment>(dbc.Payments.Find(id));
        }

        public List<DtoPayment> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoPayment>>(dbc.Payments.ToList());
        }

        public int Update(DtoPayment dtoPayment)
        {
            using DataBaseContext dbc = new();
    
            Payment payment = dbc.Payments.Find(dtoPayment.id);

            payment.clientId = dtoPayment.clientId;
            payment.paymentMethod = dtoPayment.paymentMethod;
            payment.paymentStatus = dtoPayment.paymentStatus;
            payment.paymentDate = dtoPayment.paymentDate;
            payment.amount = dtoPayment.amount;
            
            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Payment payment = dbc.Payments.Find(id);

            if (payment != null)
            {
                dbc.Payments.Remove(payment);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
