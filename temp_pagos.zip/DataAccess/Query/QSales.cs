using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QSales
    {
        public int Insert (DtoSales dtoSales)
        {
            using DataBaseContext dbc = new();

            dbc.Sales.Add(AutoMapper.mapper.Map<Sales>(dtoSales));

            return dbc.SaveChanges();
        }

        public DtoSales GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoSales>(dbc.Sales.Find(id));
        }

        public List<DtoSales> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoSales>>(dbc.Sales.ToList());
        }

        public int Update(DtoSales dtoSales)
        {
            using DataBaseContext dbc = new();
    
            Sales sales = dbc.Sales.Find(dtoSales.id);

            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Sales sales = dbc.Sales.Find(id);

            if (sales != null)
            {
                dbc.Sales.Remove(sales);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
