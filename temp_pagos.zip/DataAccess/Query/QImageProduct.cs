using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QImageProduct
    {
        public int Insert (DtoImage_Product dtoImageProduct)
        {
            using DataBaseContext dbc = new();
            dbc.ImageProducts.Add(AutoMapper.mapper.Map<Image_Product>(dtoImageProduct));
            return dbc.SaveChanges();
        }
        
        public int InsertIntoList (ICollection<DtoImage_Product> images)
        {
            using DataBaseContext dbc = new();
            foreach (DtoImage_Product image in images)
            {
                var imageProduct = AutoMapper.mapper.Map<Image_Product>(image);
                dbc.ImageProducts.Add(imageProduct);
            }
            return dbc.SaveChanges();
        }

        public int Update(DtoImage_Product dtoImageProduct)
        {
            using DataBaseContext dbc = new();
            Image_Product imageProduct = dbc.ImageProducts.Find(dtoImageProduct.id);

            if (imageProduct != null)
            {
                imageProduct.productId = dtoImageProduct.productId;
                imageProduct.url = dtoImageProduct.url;
            }
            return dbc.SaveChanges();
        }

        public int UpdateInList(ICollection<DtoImage_Product> images)
        {
            using DataBaseContext dbc = new();
            foreach (DtoImage_Product image in images)
            {
                Image_Product imageProduct = dbc.ImageProducts.FirstOrDefault(ip => ip.id == image.id);
                if (imageProduct != null)
                {
                    imageProduct.url = image.url;
                }
            }
            return dbc.SaveChanges();
        }
        
        public int DeleteOnCascade(Guid id)
        {
            using DataBaseContext dbc = new();
            ICollection<Image_Product> images = dbc.ImageProducts.Where(i => i.productId == id).ToList();
            dbc.ImageProducts.RemoveRange(images);
            return dbc.SaveChanges();
        }
        
        public bool ExistByUrl(string url)
        {
            using DataBaseContext dbc = new();
            return dbc.ImageProducts.Any(p => p.url == url);
        }
        
        public DtoImage_Product GetByUrl(Guid id)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoImage_Product>(dbc.ImageProducts.FirstOrDefault(w => w.id == id));
        }
    }
}
