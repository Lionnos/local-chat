using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QReaction
    {
        public int Insert (DtoReaction dtoReaction)
        {
            using DataBaseContext dbc = new();

            dbc.Reactions.Add(AutoMapper.mapper.Map<Reaction>(dtoReaction));

            return dbc.SaveChanges();
        }

        public DtoReaction GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoReaction>(dbc.Reactions.Find(id));
        }

        public List<DtoReaction> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoReaction>>(dbc.Reactions.ToList());
        }

        public int Update(DtoReaction dtoReaction)
        {
            using DataBaseContext dbc = new();
    
            Reaction reaction = dbc.Reactions.Find(dtoReaction.id);

            reaction.type = dtoReaction.type;
            reaction.createAt = dtoReaction.createAt;
            reaction.blogId = dtoReaction.blogId;
            reaction.clientId = dtoReaction.clientId;
            
            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Reaction reaction = dbc.Reactions.Find(id);

            if (reaction != null)
            {
                dbc.Reactions.Remove(reaction);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
