using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QReport
    {
        public int Insert (DtoReport dtoReport)
        {
            using DataBaseContext dbc = new();

            dbc.Reports.Add(AutoMapper.mapper.Map<Report>(dtoReport));

            return dbc.SaveChanges();
        }

        public DtoReport GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoReport>(dbc.Reports.Find(id));
        }

        public List<DtoReport> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoReport>>(dbc.Reports.ToList());
        }

        public int Update(DtoReport dtoReport)
        {
            using DataBaseContext dbc = new();
    
            Report report = dbc.Reports.Find(dtoReport.id);
            report.reportType = dtoReport.reportType;
            report.generatedAt = dtoReport.generatedAt;
            report.reportData = dtoReport.reportData;

            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Report report = dbc.Reports.Find(id);

            if (report != null)
            {
                dbc.Reports.Remove(report);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
