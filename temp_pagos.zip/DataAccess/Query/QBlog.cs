using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QBlog
    {
        public int Insert (DtoBlog dtoBlog)
        {
            using DataBaseContext dbc = new();

            dbc.Blogs.Add(AutoMapper.mapper.Map<Blog>(dtoBlog));

            return dbc.SaveChanges();
        }

        public DtoBlog GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoBlog>(dbc.Blogs.Find(id));
        }

        public List<DtoBlog> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoBlog>>(dbc.Blogs.ToList());
        }

        public int Update(DtoBlog dtoBlog)
        {
            using DataBaseContext dbc = new();
    
            Blog blog = dbc.Blogs.Find(dtoBlog.id);

            blog.title = dtoBlog.title;
            blog.subtitle = dtoBlog.subtitle;
            blog.content = dtoBlog.content;
            blog.status = dtoBlog.status;
            blog.userId = dtoBlog.userId;
            
            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Blog blog = dbc.Blogs.Find(id);

            if (blog != null)
            {
                dbc.Blogs.Remove(blog);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
