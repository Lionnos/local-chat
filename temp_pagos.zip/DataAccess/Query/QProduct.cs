﻿using System.Net.Mime;
using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Query
{
    public class QProduct
    {
        public int Insert (DtoProduct dtoProduct)
        {
            using DataBaseContext dbc = new();
            dbc.Products.Add(AutoMapper.mapper.Map<Product>(dtoProduct));
            return dbc.SaveChanges();
        }

        public int Update(DtoProduct dtoProduct)
        {
            using DataBaseContext dbc = new();
            Product product = dbc.Products.Find(dtoProduct.id);
            if (product != null)
            {
                product.categoryId = dtoProduct.categoryId;
                product.name = dtoProduct.name;
                product.description = dtoProduct.description;
                product.quantity = dtoProduct.quantity;
                product.status = dtoProduct.status;
                product.updatedAt = dtoProduct.updatedAt;
            }
            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();
            Product product = dbc.Products.Find(id);
            if (product != null)
            {
                dbc.Products.Remove(product);
                return dbc.SaveChanges();
            }
            return 0;
        }
        
        public DtoProduct GetProductById(Guid id)
        {
            using DataBaseContext dbc = new();
            Product product = dbc.Products
                .Include(p => p.ChidReviews)
                .Include(p => p.ChildImageProducts)
                .FirstOrDefault(p => p.id == id);
            if (product == null)
            {
                return null;
            }
            ICollection<DtoReview> dtoReviews = product.ChidReviews
                .OrderByDescending(review => review.reviewDate)
                .Take(3)
                .Select(review => AutoMapper.mapper.Map<DtoReview>(review))
                .ToList();
            ICollection<DtoImage_Product> dtoImageProducts = product.ChildImageProducts
                .Select(imageProduct => AutoMapper.mapper.Map<DtoImage_Product>(imageProduct))
                .ToList();
            DtoProduct dtoProduct = AutoMapper.mapper.Map<DtoProduct>(product);
            dtoProduct.Reviews = dtoReviews;
            dtoProduct.Images = dtoImageProducts;
            return dtoProduct;
        }

        public async Task<(ICollection<DtoProduct>, Pagination)> GetWithOffsetPagination(int pageNumber, int pageSize)
        {
            await using DataBaseContext dbc = new();
            int totalRecords = await dbc.Products.CountAsync();
            int totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);
            ICollection<Product> products = await dbc.Products
                .AsNoTracking()
                .OrderBy(p => p.name)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .Include(p => p.ChildImageProducts)
                .ToListAsync();
            ICollection<DtoProduct> listDtoProducts = AutoMapper.mapper.Map<ICollection<DtoProduct>>(products);
            foreach (DtoProduct dtoProduct in listDtoProducts)
            {
                Product product = products.First(p => p.id == dtoProduct.id);
                dtoProduct.Images = AutoMapper.mapper.Map<ICollection<DtoImage_Product>>(product.ChildImageProducts);
            }
            Pagination pagination = new Pagination
            {
                pageNumber = pageNumber,
                pageSize = pageSize,
                totalPages = totalPages,
                totalRecords = totalRecords
            };
            return (listDtoProducts, pagination);
        }

        public bool ExistByName(string name)
        {
            using DataBaseContext dbc = new();
            return dbc.Products.Any(w => w.name.Replace(" ", string.Empty) == name.Replace(" ", string.Empty));
        }
        
        public DtoProduct GetByName(string name)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoProduct>(dbc.Products.FirstOrDefault(w => w.name == name));
        }
    }
}
