using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QAddress
    {
        public int Insert (DtoAddress dtoAddress)
        {
            using DataBaseContext dbc = new();

            dbc.Addresses.Add(AutoMapper.mapper.Map<Address>(dtoAddress));

            return dbc.SaveChanges();
        }

        public DtoAddress GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoAddress>(dbc.Addresses.Find(id));
        }

        public List<DtoAddress> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoAddress>>(dbc.Addresses.ToList());
        }

        public int Update(DtoAddress dtoAddress)
        {
            using DataBaseContext dbc = new();
    
            Address address = dbc.Addresses.Find(dtoAddress.id);

            address.clientId = dtoAddress.clientId;

            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Address address = dbc.Addresses.Find(id);

            if (address != null)
            {
                dbc.Addresses.Remove(address);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
