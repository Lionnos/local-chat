using DataAccess.Connection;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QAuthentication
    {
        public DtoAuthentication SearchByUsernameUser(string username)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoAuthentication>(dbc.Users.FirstOrDefault(w => w.username == username));
        }
        
        public DtoAuthentication SearchByUsernameClient(string username)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoAuthentication>(dbc.Clients.FirstOrDefault(w => w.username == username));
        }
        
        public DtoAuthentication GetByEmailClient(string email)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoAuthentication>(dbc.Clients.FirstOrDefault(w => w.email == email));
        }
    }
}
