using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QSalesDetail
    {
        public int Insert (DtoSalesDetail dtoSalesDetail)
        {
            using DataBaseContext dbc = new();

            dbc.SalesDetails.Add(AutoMapper.mapper.Map<SalesDetail>(dtoSalesDetail));

            return dbc.SaveChanges();
        }

        public DtoSalesDetail GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoSalesDetail>(dbc.SalesDetails.Find(id));
        }

        public List<DtoSalesDetail> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoSalesDetail>>(dbc.SalesDetails.ToList());
        }

        public int Update(DtoSalesDetail dtoSalesDetail)
        {
            using DataBaseContext dbc = new();
    
            SalesDetail salesDetail = dbc.SalesDetails.Find(dtoSalesDetail.id);

            salesDetail.productId = dtoSalesDetail.productId;
            salesDetail.saleId = dtoSalesDetail.saleId;
            salesDetail.quantity = dtoSalesDetail.quantity;
            salesDetail.unitPrice = dtoSalesDetail.unitPrice;
            salesDetail.subTotalPrice = dtoSalesDetail.subTotalPrice;
            
            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            SalesDetail salesDetail = dbc.SalesDetails.Find(id);

            if (salesDetail != null)
            {
                dbc.SalesDetails.Remove(salesDetail);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
