using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess.Query
{
    public class QComment
    {
        public int Insert (DtoComment dtoComment)
        {
            using DataBaseContext dbc = new();

            dbc.Comments.Add(AutoMapper.mapper.Map<Comment>(dtoComment));

            return dbc.SaveChanges();
        }

        public DtoComment GetById(Guid id)
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<DtoComment>(dbc.Comments.Find(id));
        }

        public List<DtoComment> GetAll()
        {
            using DataBaseContext dbc = new();

            return AutoMapper.mapper.Map<List<DtoComment>>(dbc.Comments.ToList());
        }

        public int Update(DtoComment dtoComment)
        {
            using DataBaseContext dbc = new();
    
            Comment comment = dbc.Comments.Find(dtoComment.id);

            comment.content = dtoComment.content;
            comment.blogId = dtoComment.blogId;
            comment.clientId = dtoComment.clientId; 
            comment.createdAt = dtoComment.createdAt;
            comment.updatedAt = dtoComment.updatedAt;
            
            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();

            Comment comment = dbc.Comments.Find(id);

            if (comment != null)
            {
                dbc.Comments.Remove(comment);
                return dbc.SaveChanges();
            }

            return 0;
        }
    }
}
