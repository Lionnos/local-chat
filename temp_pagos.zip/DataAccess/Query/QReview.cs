using DataAccess.Connection;
using DataAccess.Entity;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;
using Microsoft.EntityFrameworkCore;

namespace DataAccess.Query
{
    public class QReview
    {
        public int Insert (DtoReview dtoReview)
        {
            using DataBaseContext dbc = new();
            dbc.Reviews.Add(AutoMapper.mapper.Map<Review>(dtoReview));
            return dbc.SaveChanges();
        }

        public DtoReview GetById(Guid id)
        {
            using DataBaseContext dbc = new();
            return AutoMapper.mapper.Map<DtoReview>(dbc.Reviews.Find(id));
        }

        public (ICollection<DtoReview>, Pagination) GetWithPagination(int pageNumber, int pageSize)
        {
            using DataBaseContext dbc = new();
            int totalRecords = dbc.Reviews.Count();
            int totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);
            ICollection<Review> reviews = dbc.Reviews
                .AsNoTracking()
                .OrderBy(p => p.reviewDate)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .ToList();
    
            ICollection<DtoReview> listDtoReviews = AutoMapper.mapper.Map<ICollection<DtoReview>>(reviews);
            Pagination pagination = new Pagination
            {
                pageNumber = pageNumber,
                pageSize = pageSize,
                totalPages = totalPages,
                totalRecords = totalRecords
            };
            return (listDtoReviews, pagination);
        }
        
        public (ICollection<DtoReview>, Pagination) GetWithPaginationAndClient(int pageNumber, int pageSize)
        {
            using DataBaseContext dbc = new();
            int totalRecords = dbc.Reviews.Count();
            int totalPages = (int)Math.Ceiling(totalRecords / (double)pageSize);
            ICollection<Review> reviews = dbc.Reviews
                .AsNoTracking()
                .OrderBy(p => p.reviewDate)
                .Skip((pageNumber - 1) * pageSize)
                .Take(pageSize)
                .Include(c=>c.ParentClient)
                .ToList();
    
            ICollection<DtoReview> listDtoReviews = AutoMapper.mapper.Map<ICollection<DtoReview>>(reviews);
            Pagination pagination = new Pagination
            {
                pageNumber = pageNumber,
                pageSize = pageSize,
                totalPages = totalPages,
                totalRecords = totalRecords
            };
            return (listDtoReviews, pagination);
        }

        public int Update(DtoReview dtoReview)
        {
            using DataBaseContext dbc = new();
            Review review = dbc.Reviews.Find(dtoReview.id);
            if (review != null)
            {
                review.productId = dtoReview.productId;
                review.clientId = dtoReview.clientId;
                review.rating = dtoReview.rating;
                review.reviewText = dtoReview.reviewText;
                review.reviewDate = dtoReview.reviewDate;
            }
            return dbc.SaveChanges();
        }

        public int Delete(Guid id)
        {
            using DataBaseContext dbc = new();
            Review review = dbc.Reviews.Find(id);
            if (review != null)
            {
                dbc.Reviews.Remove(review);
                return dbc.SaveChanges();
            }
            return 0;
        }
        
        public int DeleteOnCascade(Guid id)
        {
            using DataBaseContext dbc = new();

            ICollection<Review> reviews = dbc.Reviews.Where(i => i.productId == id).ToList();

            dbc.Reviews.RemoveRange(reviews);

            return dbc.SaveChanges();
        }
    }
}
