﻿using AutoMapper;
using DataAccess.Entity;
using DataTransfer.Objects;

namespace DataAccess
{
    public static class AutoMapper
    {
        private static bool _initMapper = true;
        public static IMapper mapper;

        public static void start()
        {
            if (_initMapper)
            {
                var config = new MapperConfiguration(cfg =>
                {
                    cfg.CreateMap<DtoUser, User>().MaxDepth(7);
                    cfg.CreateMap<User, DtoUser>().MaxDepth(7);

                    cfg.CreateMap<DtoAddition, Addition>().MaxDepth(7);
                    cfg.CreateMap<Addition, DtoAddition>().MaxDepth(7);

                    cfg.CreateMap<DtoAddress, Address>().MaxDepth(7);
                    cfg.CreateMap<Address, DtoAddress>().MaxDepth(7);

                    cfg.CreateMap<DtoCategory, Category>().MaxDepth(7);
                    cfg.CreateMap<Category, DtoCategory>().MaxDepth(7);

                    cfg.CreateMap<DtoClient, Client>().MaxDepth(7);
                    cfg.CreateMap<Client, DtoClient>().MaxDepth(7);

                    cfg.CreateMap<DtoImage_Product, Image_Product>().MaxDepth(7);
                    cfg.CreateMap<Image_Product, DtoImage_Product>().MaxDepth(7);

                    cfg.CreateMap<DtoPayment, Payment>().MaxDepth(7);
                    cfg.CreateMap<Payment, DtoPayment>().MaxDepth(7);

                    cfg.CreateMap<DtoProduct, Product>().MaxDepth(7);
                    cfg.CreateMap<Product, DtoProduct>().MaxDepth(7);

                    cfg.CreateMap<DtoReview, Review>().MaxDepth(7);
                    cfg.CreateMap<Review, DtoReview>().MaxDepth(7);

                    cfg.CreateMap<DtoSales, Sales>().MaxDepth(7);
                    cfg.CreateMap<Sales, DtoSales>().MaxDepth(7);

                    cfg.CreateMap<DtoSalesDetail, SalesDetail>().MaxDepth(7);
                    cfg.CreateMap<SalesDetail, DtoSalesDetail>().MaxDepth(7);

                    cfg.CreateMap<DtoSalesHistory, SalesHistory>().MaxDepth(7);
                    cfg.CreateMap<SalesHistory, DtoSalesHistory>().MaxDepth(7);

                    cfg.CreateMap<DtoSubtraction, Subtraction>().MaxDepth(7);
                    cfg.CreateMap<Subtraction, DtoSubtraction>().MaxDepth(7);
                    
                    cfg.CreateMap<User, DtoAuthentication>().MaxDepth(1)
                        .ForMember(dest => dest.id, opt => opt.MapFrom(src => src.id))
                        .ForMember(dest => dest.username, opt => opt.MapFrom(src => src.username))
                        .ForMember(dest => dest.password, opt => opt.MapFrom(src => src.password))
                        .ForMember(dest => dest.status, opt => opt.MapFrom(src => src.status));
                    
                    cfg.CreateMap<Client, DtoAuthentication>().MaxDepth(1)
                        .ForMember(dest => dest.id, opt => opt.MapFrom(src => src.id))
                        .ForMember(dest => dest.username, opt => opt.MapFrom(src => src.username))
                        .ForMember(dest => dest.password, opt => opt.MapFrom(src => src.password))
                        .ForMember(dest => dest.status, opt => opt.MapFrom(src => src.status));
                });
                mapper = config.CreateMapper();
                _initMapper = false;

            }
        }
    }
}
