using System.Text;
using RestSharp;

namespace Business.Niubiz
{
    public class NiubizService (string accessKey, string secretKey, string apiUrl)
    {
        private string MerchantId;
        private string AccessKey = accessKey;
        private string SecretKey = secretKey;
        private string ApiUrl = apiUrl;
        
        public async Task<string> CreateSession()
        {
            var options = new RestClientOptions(ApiUrl);
            var client = new RestClient(options);
            var request = new RestRequest("");
            request.AddHeader("accept", "text/plain");
            request.AddHeader("authorization", "Basic " + GenerateAuthorizationHeader(AccessKey, SecretKey));
            try
            {
                var response = await client.ExecuteAsync(request);
                if (response.IsSuccessful)
                {
                    return response.Content;
                }
                else
                {
                    throw new Exception($"Error en la solicitud: {response.StatusCode} - {response.ErrorMessage}");
                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error al crear la sesión", ex);
            }
        }

        private string GenerateAuthorizationHeader(string username, string password)
        {
            string credentials = $"{username}:{password}";
            byte[] credentialsBytes = Encoding.UTF8.GetBytes(credentials);
            string base64Credentials = Convert.ToBase64String(credentialsBytes);
            return base64Credentials;
        }
    }
}

