using DataAccess.Query;

namespace Business.Business.Comment
{
    public partial class BusinessComment
    {
        private QComment qComment = new();
    }
}