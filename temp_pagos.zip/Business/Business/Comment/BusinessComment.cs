using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Comment
{
    public partial class BusinessComment : BusinessGeneric
    {
        public DtoMessageObject Insert(DtoComment dtoComment)
        {
            using TransactionScope transactionScope = new();

            InsertValidation(dtoComment);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoComment.id = Guid.NewGuid();
            dtoComment.createdAt = DateTime.Now;
            dtoComment.updatedAt = DateTime.Now;

            qComment.Insert(dtoComment);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public (DtoMessageObject, DtoComment) GetById(Guid id)
        {
            _mo.Success();

            return (_mo, qComment.GetById(id));
        }

        public (DtoMessageObject, List<DtoComment>) GetAll()
        {
            _mo.Success();

            return (_mo, qComment.GetAll());
        }

        public DtoMessageObject Delete(Guid id)
        {
            qComment.Delete(id);

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public DtoMessageObject Update(DtoComment dtoComment)
        {
            using TransactionScope transactionScope = new();

            UpdateValidation(dtoComment);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoComment.updatedAt = DateTime.Now;

            qComment.Update(dtoComment);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }
    }
}
