using DataTransfer.Objects;

namespace Business.Business.Comment
{
    public partial class BusinessComment
    {
        private void InsertValidation(DtoComment dtoComment)
        {

        }

        private void UpdateValidation(DtoComment dtoComment)
        {

        }
    }
}