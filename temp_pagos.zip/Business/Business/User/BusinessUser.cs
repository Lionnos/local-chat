﻿using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;
using System.Transactions;

namespace Business.Business.User
{
    public partial class BusinessUser : BusinessGeneric
    {
        public DtoMessageObject GetByEmail(string email)
        {
            var dtoUser = qUser.GetByEmail(email);
            if (dtoUser == null)
            {
                _mo.AddMessage("Correo electronico NO encontrado.");
                _mo.Error();
                return _mo;
            }
            _mo.AddMessage("Correo electronico encontrado.");
            _mo.Success();
            return _mo;
        }

        public (DtoMessageObject, DtoUser) Register(DtoUser dtoUser)
        {
            using TransactionScope transactionScope = new();
            insertValidation(dtoUser);
            if (_mo.ExsistsMessage())
            {
                return (_mo, null);
            }

            dtoUser.id = Guid.NewGuid();
            dtoUser.createdAt = DateTime.Now;
            dtoUser.updatedAt = DateTime.Now;
            dtoUser.password = BCrypt.Net.BCrypt.HashPassword(dtoUser.password);
            dtoUser.status = false;
            dtoUser.role = Hierarchy.Other;

            qUser.Register(dtoUser);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return (_mo, dtoUser);
        }

        public (DtoMessageObject, DtoUser) GetByUsername(string username)
        {
            var dtoUser = qUser.GetByUsername(username);
            if (dtoUser != null)
            {
                _mo.Success();
            }
            else
            {
                _mo.AddMessage("Usuario no encontrado.");
                _mo.Error();
            }
            return (_mo, dtoUser);
        }

        public (DtoMessageObject, DtoUser) MyProfile(Guid id)
        {
            _mo.Success();
            return (_mo, qUser.myProfile(id));
        }
        
        public DtoMessageObject ConfirmEmail(string email)
        {
            var dtoUser = qUser.GetByEmail(email);
            if (dtoUser == null)
            {
                _mo.AddMessage("Usuario no encontrado.");
                _mo.Error();
                return _mo;
            }
            dtoUser.status = true;
            dtoUser.updatedAt = DateTime.Now;
            qUser.Update(dtoUser);

            _mo.AddMessage("Correo confirmado exitosamente.");
            _mo.Success();
            return _mo;
        }
        
          public DtoMessageObject ChangePassword(DtoRecovery dtoRecovery)
          {
            var dtoUser = qUser.GetByEmail(dtoRecovery.email);
            if (dtoUser == null)
            {
                _mo.AddMessage("Usuario no encontrado.");
                _mo.Error();
                return _mo;
            }
            dtoUser.password = BCrypt.Net.BCrypt.HashPassword(dtoRecovery.newPassword);
            dtoUser.updatedAt = DateTime.Now;
            qUser.Update(dtoUser);

            _mo.AddMessage("Contraseña cambiada exitosamente");
            _mo.Success();
            return _mo;
          }
        
        public DtoMessageObject Update(DtoUser dtoUser)
        {
            using TransactionScope transactionScope = new();
            dtoUser.username = dtoUser.username;
            dtoUser.firstName = dtoUser.firstName;
            dtoUser.lastName = dtoUser.lastName;
            dtoUser.email = dtoUser.email;
            dtoUser.dni = dtoUser.dni;
            dtoUser.ruc = dtoUser.ruc;
            dtoUser.status = dtoUser.status;
            dtoUser.role = dtoUser.role;
            dtoUser.phoneNumber = dtoUser.phoneNumber;
            dtoUser.updatedAt = DateTime.Now;
            dtoUser.password = BCrypt.Net.BCrypt.HashPassword(dtoUser.password);
            qUser.Update(dtoUser);
            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();
            return _mo;
        }
    }
}
