﻿using DataTransfer.Objects;

namespace Business.Business.User
{
    public partial class BusinessUser
    {
        private void insertValidation(DtoUser dto)
        {
            if (qUser.GetByDni(dto.dni) is not null)
            {
                _mo.AddMessage("El usuario ya existe (DNI existe)");
            }
            if (qUser.GetByUsername(dto.username) is not null)
            {
                _mo.AddMessage("El usuario ya existe (Nombre de usuario existente)");
            }
            if (qUser.GetByEmail(dto.email) is not null){
                _mo.AddMessage("El usuario ya existe (Email existente)");
            }
        }
    }
}
