﻿using DataAccess.Query;

namespace Business.Business.User
{
    public partial class BusinessUser
    {
        private QUser qUser = new();
    }
}
