using DataAccess.Query;

namespace Business.Business.Authentication
{
    public partial class BusinessAuthentication
    {
        private readonly QAuthentication qAuthentication = new();
    }
}
