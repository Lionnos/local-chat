using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Authentication
{
    public partial class BusinessAuthentication : BusinessGeneric
    {
        public (DtoMessageObject, DtoAuthentication) SearchByUser(string username)
        {
            DtoAuthentication dtoAuthentication = qAuthentication.SearchByUsernameUser(username);
            if (dtoAuthentication != null)
            {
                _mo.Success();
            }
            else
            {
                _mo.AddMessage("Usuario no encontrado.");
                _mo.Error();
            }
            return (_mo, dtoAuthentication);
        }
        
        public (DtoMessageObject, DtoAuthentication) GetByUsernameClient(string username)
        {
            var dtoAuthentication = qAuthentication.SearchByUsernameClient(username);
            if (dtoAuthentication != null)
            {
                _mo.Success();
            }
            else
            {
                _mo.AddMessage("Usuario no encontrado.");
                _mo.Error();
            }
            return (_mo, dtoAuthentication);
        }
        
        public (DtoMessageObject, DtoAuthentication) GetByEmailClient(string email)
        {
            var dtoAuthentication = qAuthentication.GetByEmailClient(email);
            if (dtoAuthentication != null)
            {
                _mo.Success();
            }
            else
            {
                _mo.AddMessage("Usuario no encontrado.");
                _mo.Error();
            }
            return (_mo, dtoAuthentication);
        }
    }
}
