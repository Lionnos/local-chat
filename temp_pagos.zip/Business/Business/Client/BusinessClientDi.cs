using DataAccess.Query;

namespace Business.Business.Client
{
    public partial class BusinessClient
    {
        private QClient qClient = new ();
        private QAddress qAddress = new();
    }
}
