using DataTransfer.Objects;

namespace Business.Business.Client
{
    public partial class BusinessClient
    {
        private void InsertValidation(DtoClient dtoClient)
        {
            if (qClient.GetByNumberDocument(dtoClient.documentNumber) is not null)
            {
                _mo.AddMessage("El numero de documento ya existe");
            }

            if (qClient.GetByEmail(dtoClient.email) is not null)
            {
                _mo.AddMessage("El correo ya existe (Correo existente)");
            }
        }

        private void UpdateValidation(DtoClient dtoClient)
        {
            DtoClient DtoClientTempDocument = qClient.GetByNumberDocument(dtoClient.documentNumber);

            if (DtoClientTempDocument is not null && DtoClientTempDocument.documentNumber == dtoClient.documentNumber)
            {
                _mo.AddMessage("El numero de documento ya existe");
            }

            DtoClient dtoClientTempEmail = qClient.GetByEmail(dtoClient.email);

            if (dtoClientTempEmail is not null && dtoClientTempEmail.email == dtoClient.email)
            {
                _mo.AddMessage("l correo ya existe (Correo existente)");
            }
        }
    }
}