using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Client
{
    public partial class BusinessClient : BusinessGeneric
    {
        public (DtoMessageObject, DtoClient) Register(DtoClient dtoClient)
        {
            using TransactionScope transactionScope = new();
            InsertValidation(dtoClient);
            if (_mo.ExsistsMessage())
            {
                return (_mo, null);
            }

            dtoClient.id = Guid.NewGuid();
            dtoClient.password = BCrypt.Net.BCrypt.HashPassword(dtoClient.password);
            dtoClient.status = true; //// adsfasdfa
            dtoClient.role = Hierarchy.Logged;
            dtoClient.createdAt = DateTime.Now;
            dtoClient.updatedAt = DateTime.Now;
            qClient.Register(dtoClient);
            transactionScope.Complete();
            
            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();
            return (_mo, dtoClient);
        }

        public (DtoMessageObject, DtoClient) GetById(Guid id)
        {
            _mo.Success();
            return (_mo, qClient.GetById(id));
        }

        public (DtoMessageObject, List<DtoClient>) GetAll()
        {
            _mo.Success();
            return (_mo, qClient.GetAll());
        }

        public DtoMessageObject Delete(Guid id)
        {
            qClient.Delete(id);
            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();
            return _mo;
        }

        public DtoMessageObject Update(DtoClient dtoClient)
        {
            using TransactionScope transactionScope = new();
            UpdateValidation(dtoClient);
            if (_mo.ExsistsMessage())
            {
                return _mo;
            }
            dtoClient.updatedAt = DateTime.Now;
            qClient.Update(dtoClient);
            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();
            return _mo;
        }
        
        public (DtoMessageObject, DtoClient) GetByUsername(string username)
        {
            var dtoClient = qClient.GetByUsername(username);
            if (dtoClient != null)
            {
                _mo.Success();
            }
            else
            {
                _mo.AddMessage("Usuario no encontrado.");
                _mo.Error();
            }
            return (_mo, dtoClient);
        }
    }
}
