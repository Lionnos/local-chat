using DataAccess.Query;

namespace Business.Business.SalesDetail
{
    public partial class BusinessSaleDetail
    {
        private QSalesDetail qSalesDetail = new();
    }
}