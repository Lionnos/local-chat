using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.SalesDetail
{
    public partial class BusinessSaleDetail : BusinessGeneric
    {
        public DtoMessageObject Insert(DtoSalesDetail dtoSalesDetail)
        {
            using TransactionScope transactionScope = new();

            InsertValidation(dtoSalesDetail);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoSalesDetail.id = Guid.NewGuid();

            qSalesDetail.Insert(dtoSalesDetail);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public (DtoMessageObject, DtoSalesDetail) GetById(Guid id)
        {
            _mo.Success();

            return (_mo, qSalesDetail.GetById(id));
        }

        public (DtoMessageObject, List<DtoSalesDetail>) GetAll()
        {
            _mo.Success();

            return (_mo, qSalesDetail.GetAll());
        }

        public DtoMessageObject Delete(Guid id)
        {
            qSalesDetail.Delete(id);

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public DtoMessageObject Update(DtoSalesDetail dtoSalesDetail)
        {
            using TransactionScope transactionScope = new();

            UpdateValidation(dtoSalesDetail);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            qSalesDetail.Update(dtoSalesDetail);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }
    }
}
