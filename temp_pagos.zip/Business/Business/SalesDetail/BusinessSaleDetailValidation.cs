using DataTransfer.Objects;

namespace Business.Business.SalesDetail
{
    public partial class BusinessSaleDetail
    {
        private void InsertValidation(DtoSalesDetail dtoSalesDetail)
        {

        }

        private void UpdateValidation(DtoSalesDetail dtoSalesDetail)
        {

        }
    }
}