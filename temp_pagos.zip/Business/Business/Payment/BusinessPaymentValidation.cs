using DataTransfer.Objects;

namespace Business.Business.Payment
{
    public partial class BusinessPayment
    {
        private void InsertValidation(DtoPayment dtoPayment)
        {

        }

        private void UpdateValidation(DtoPayment dtoPayment)
        {

        }
    }
}