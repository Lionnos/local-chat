using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Payment
{
    public partial class BusinessPayment : BusinessGeneric
    {
        public DtoMessageObject Insert(DtoPayment dtoPayment)
        {
            using TransactionScope transactionScope = new();

            InsertValidation(dtoPayment);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoPayment.id = Guid.NewGuid();

            qPayment.Insert(dtoPayment);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public (DtoMessageObject, DtoPayment) GetById(Guid id)
        {
            _mo.Success();

            return (_mo, qPayment.GetById(id));
        }

        public (DtoMessageObject, List<DtoPayment>) GetAll()
        {
            _mo.Success();

            return (_mo, qPayment.GetAll());
        }

        public DtoMessageObject Delete(Guid id)
        {
            qPayment.Delete(id);

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public DtoMessageObject Update(DtoPayment dtoPayment)
        {
            using TransactionScope transactionScope = new();

            UpdateValidation(dtoPayment);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            qPayment.Update(dtoPayment);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }
    }
}
