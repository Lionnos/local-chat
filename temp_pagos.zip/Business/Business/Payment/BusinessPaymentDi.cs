using DataAccess.Query;

namespace Business.Business.Payment
{
    public partial class BusinessPayment
    {
        private QPayment qPayment = new();
    }
}