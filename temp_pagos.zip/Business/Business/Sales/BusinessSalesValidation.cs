using DataTransfer.Objects;

namespace Business.Business.Sales
{
    public partial class BusinessSales
    {
        private void InsertValidation(DtoSales dtoSales)
        {

        }

        private void UpdateValidation(DtoSales dtoSales)
        {

        }
    }
}