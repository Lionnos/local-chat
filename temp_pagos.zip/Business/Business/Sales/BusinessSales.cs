using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Sales
{
    public partial class BusinessSales : BusinessGeneric
    {
        public DtoMessageObject Insert(DtoSales dtoSales)
        {
            using TransactionScope transactionScope = new();

            InsertValidation(dtoSales);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoSales.id = Guid.NewGuid();

            qSales.Insert(dtoSales);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public (DtoMessageObject, DtoSales) GetById(Guid id)
        {
            _mo.Success();

            return (_mo, qSales.GetById(id));
        }

        public (DtoMessageObject, List<DtoSales>) GetAll()
        {
            _mo.Success();

            return (_mo, qSales.GetAll());
        }

        public DtoMessageObject Delete(Guid id)
        {
            qSales.Delete(id);

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public DtoMessageObject Update(DtoSales dtoSales)
        {
            using TransactionScope transactionScope = new();

            UpdateValidation(dtoSales);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            qSales.Update(dtoSales);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }
    }
}
