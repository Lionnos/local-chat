using Business.Generic;
using DataAccess.Query;

namespace Business.Business.Sales
{
    public partial class BusinessSales
    {
        private QSales qSales = new ();
    }
}
