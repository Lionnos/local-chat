using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Review
{
    public partial class BusinessReview : BusinessGeneric
    {
        public DtoMessageObject Insert(DtoReview dtoReview)
        {
            using TransactionScope transactionScope = new();
            InsertValidation(dtoReview);
            if (_mo.ExsistsMessage())
            {
                return _mo;
            }
            dtoReview.id = Guid.NewGuid();
            dtoReview.reviewDate = DateTime.Now;
            dtoReview.reviewText = dtoReview.reviewText.TrimStart();
            qReview.Insert(dtoReview);
            transactionScope.Complete();
            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();
            return _mo;
        }

        public (DtoMessageObject, DtoReview) GetById(Guid id)
        {
            _mo.Success();
            return (_mo, qReview.GetById(id));
        }

        public (DtoMessageObject, ICollection<DtoReview>, Pagination) GetWithPagination(int pageNumber, int pageSize)
        {
            var (reviews, pagination) = qReview.GetWithPagination(pageNumber, pageSize);
            _mo.Success();
            return (_mo, reviews, pagination);
        }

        public DtoMessageObject Delete(Guid id)
        {
            qReview.Delete(id);
            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();
            return _mo;
        }

        public DtoMessageObject Update(DtoReview dtoReview)
        {
            using TransactionScope transactionScope = new();
            UpdateValidation(dtoReview);
            if (_mo.ExsistsMessage())
            {
                return _mo;
            }
            dtoReview.reviewText = dtoReview.reviewText.TrimStart();
            dtoReview.reviewDate = DateTime.Now;
            qReview.Update(dtoReview);
            transactionScope.Complete();
            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }
    }
}
