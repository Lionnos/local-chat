using DataAccess.Query;

namespace Business.Business.Review
{
    public partial class BusinessReview
    {
        private QReview qReview = new();
    }
}