using DataTransfer.Objects;

namespace Business.Business.Review
{
    public partial class BusinessReview
    {
        private void InsertValidation(DtoReview dtoReview)
        {

        }

        private void UpdateValidation(DtoReview dtoReview)
        {

        }
    }
}