using DataTransfer.Objects;

namespace Business.Business.Category
{
    public partial class BusinessCategory
    {
        private void InsertValidation(DtoCategory dtoCategory)
        {
            if (qCategory.ExistByName(dtoCategory.name))
            {
                _mo.AddMessage("La categoria ya se encuentra registrado (nombre existente)");
            }
        }

        private void UpdateValidation(DtoCategory dtoCategory)
        {
            DtoCategory category = qCategory.GetByName(dtoCategory.name.TrimStart());
            
            if (qCategory.GetByName(dtoCategory.name.TrimStart()) is not null && 
                category.name.TrimStart() == dtoCategory.name)
            {
                _mo.AddMessage("La categoria ya se encuentra registrado (nombre existente)");
            }
        }
    }
}