using DataAccess.Query;

namespace Business.Business.Category
{
    public partial class BusinessCategory
    {
        private QCategory qCategory = new();
    }
}