using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Category
{
    public partial class BusinessCategory : BusinessGeneric
    {
        public DtoMessageObject Insert(DtoCategory dtoCategory)
        {
            using TransactionScope transactionScope = new();

            InsertValidation(dtoCategory);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoCategory.id = Guid.NewGuid();
            dtoCategory.createdAt = DateTime.Now;
            dtoCategory.updatedAt = DateTime.Now;
            dtoCategory.name = dtoCategory.name.TrimStart();
            qCategory.Insert(dtoCategory);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public (DtoMessageObject, DtoCategory) GetById(Guid id)
        {
            _mo.Success();

            return (_mo, qCategory.GetById(id));
        }
        
        public (DtoMessageObject, ICollection<DtoCategory>, Pagination) GetWithPagination(int pageNumber, int pageSize)
        {
            var (categories, pagination) = qCategory.GetWithPagination(pageNumber, pageSize);
            _mo.Success();
            return (_mo, categories, pagination);
        }
        
        public DtoMessageObject Delete(Guid id)
        {
            qCategory.Delete(id);

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public DtoMessageObject Update(DtoCategory dtoCategory)
        {
            using TransactionScope transactionScope = new();
            UpdateValidation(dtoCategory);
            if (_mo.ExsistsMessage())
            {
                return _mo;
            }
            dtoCategory.updatedAt = DateTime.Now;
            dtoCategory.name = dtoCategory.name.TrimStart();
            qCategory.Update(dtoCategory);
            transactionScope.Complete();
            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();
            return _mo;
        }
    }
}
