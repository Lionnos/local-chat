using DataTransfer.Objects;

namespace Business.Business.Blog
{
    public partial class BusinessBlog
    {
        private void InsertValidation(DtoBlog dtoBlog)
        {

        }

        private void UpdateValidation(DtoBlog dtoBlog)
        {

        }
    }
}
