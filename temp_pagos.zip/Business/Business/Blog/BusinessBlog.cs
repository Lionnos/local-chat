using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Blog
{
    public partial class BusinessBlog : BusinessGeneric
    {
        public DtoMessageObject Insert(DtoBlog dtoBlog)
        {
            using TransactionScope transactionScope = new();

            InsertValidation(dtoBlog);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoBlog.id = Guid.NewGuid();
            dtoBlog.createdAt = DateTime.Now;
            dtoBlog.updatedAt = DateTime.Now;

            qBlog.Insert(dtoBlog);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public (DtoMessageObject, DtoBlog) GetById(Guid id)
        {
            _mo.Success();

            return (_mo, qBlog.GetById(id));
        }

        public (DtoMessageObject, List<DtoBlog>) GetAll()
        {
            _mo.Success();

            return (_mo, qBlog.GetAll());
        }

        public DtoMessageObject Delete(Guid id)
        {
            qBlog.Delete(id);

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public DtoMessageObject Update(DtoBlog dtoBlog)
        {
            using TransactionScope transactionScope = new();

            UpdateValidation(dtoBlog);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoBlog.updatedAt = DateTime.Now;

            qBlog.Update(dtoBlog);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }
    }
}
