using DataAccess.Query;

namespace Business.Business.Blog
{
    public partial class BusinessBlog
    {
        private QBlog qBlog = new();
    }
}
