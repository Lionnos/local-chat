using DataAccess.Query;

namespace Business.Business.Product
{
    public partial class BusinessProduct
    {
        private QProduct qProduct = new();
        private QImageProduct qImageProduct = new();
        private QReview qReview = new();
        private QUser qUser = new();
    }
}