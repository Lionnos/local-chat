using DataTransfer.Objects;

namespace Business.Business.Product
{
    public partial class BusinessProduct 
    {
        private void InsertValidation(DtoProduct dtoProduct)
        {
            if (qProduct.ExistByName(dtoProduct.name))
            {
                _mo.AddMessage("El producto con este nombre ya existe (nombre existente)");
            }

            if (dtoProduct.Images != null)
            {
                foreach (DtoImage_Product images in dtoProduct.Images)
                {
                    if (qImageProduct.ExistByUrl(images.url))
                    {
                        _mo.AddMessage($"La imagen ya existe ({images.url} existente)");
                    }
                }
            }
        }

        private void UpdateValidation(DtoProduct dtoProduct)
        {
            DtoProduct productTemp = qProduct.GetByName(dtoProduct.name);
            if (qProduct.GetByName(dtoProduct.name) is not null && productTemp.name == dtoProduct.name)
            {
                _mo.AddMessage("El producto con este nombre ya existe (nombre existente)");
            }
        }
        
        private void UpdateValidationWithImage(DtoProduct dtoProduct)
        {
            DtoProduct productTemp = qProduct.GetByName(dtoProduct.name);
            if (qProduct.GetByName(dtoProduct.name) is not null && productTemp.name == dtoProduct.name)
            {
                _mo.AddMessage("El producto con este nombre ya existe (nombre existente)");
            }

            if (dtoProduct.Images != null)
            {
                foreach (DtoImage_Product images in dtoProduct.Images)
                {
                    DtoImage_Product imagesTemp = qImageProduct.GetByUrl(images.id);
                    
                    if (qImageProduct.GetByUrl(images.id) is not null && imagesTemp.url == images.url)
                    {
                        _mo.AddMessage($"La imagen ya existe ({images.url} existente)");
                    }
                }
            }
        }

        private void DeleteValidation(Guid id, string password)
        {
            string passwordById = qUser.GetPasswordById(id);
            
            if (passwordById == null)
            {
                _mo.AddMessage("Ocurrió un error inténtelo nuevamente.");
                return;
            }

            if (!BCrypt.Net.BCrypt.Verify(password, passwordById))
            {
                _mo.AddMessage("Contraseña incorrecta");
            }
        }
    }
}