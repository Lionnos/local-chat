﻿using System.Transactions;
using Business.Generic;
using DataTransfer.Objects;
using DataTransfer.OtherObjects;

namespace Business.Business.Product
{
    public partial class BusinessProduct : BusinessGeneric
    {
        public DtoMessageObject Insert(DtoProduct dtoProduct)
        {
            using TransactionScope transactionScope = new();

            InsertValidation(dtoProduct);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoProduct.id = Guid.NewGuid();
            dtoProduct.status = true;
            dtoProduct.createdAt = DateTime.Now;
            dtoProduct.updatedAt = DateTime.Now;

            foreach (DtoImage_Product image in dtoProduct.Images)
            {
                image.id = Guid.NewGuid();
                image.productId = dtoProduct.id;
            }
            
            qProduct.Insert(dtoProduct);
            qImageProduct.InsertIntoList(dtoProduct.Images);

            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public async Task<(DtoMessageObject, ICollection<DtoProduct>, Pagination)> GetWithOffsetPagination(int pageNumber, int pageSize)
        {
            _mo.Success();
            var (products, pagination) = await qProduct.GetWithOffsetPagination(pageNumber, pageSize);
            return (_mo, products, pagination);
        }

        public DtoMessageObject Delete(Guid id, Guid userId, string password)
        {
            DeleteValidation(userId, password);
            
            if (_mo.ExsistsMessage())
            {
                return _mo;
            }
            
            qImageProduct.DeleteOnCascade(id);
            qReview.DeleteOnCascade(id);
            qProduct.Delete(id);

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public DtoMessageObject Update(DtoProduct dtoProduct)
        {
            using TransactionScope transactionScope = new();

            UpdateValidation(dtoProduct);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoProduct.updatedAt = DateTime.Now;

            qProduct.Update(dtoProduct);
                
            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }
        
        public DtoMessageObject UpdateOnImages(DtoProduct dtoProduct)
        {
            using TransactionScope transactionScope = new();

            UpdateValidationWithImage(dtoProduct);

            if (_mo.ExsistsMessage())
            {
                return _mo;
            }

            dtoProduct.updatedAt = DateTime.Now;

            qProduct.Update(dtoProduct);
            qImageProduct.UpdateInList(dtoProduct.Images);
                
            transactionScope.Complete();

            _mo.AddMessage("Operación realizada correctamente.");
            _mo.Success();

            return _mo;
        }

        public (DtoMessageObject, DtoProduct) GetProductById(Guid id)
        {
            _mo.Success();

            return (_mo, qProduct.GetProductById(id)); 
        }
    }
}
