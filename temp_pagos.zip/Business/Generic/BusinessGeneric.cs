﻿using DataTransfer.OtherObjects;

namespace Business.Generic
{
    public abstract class BusinessGeneric
    {
        public DtoMessageObject _mo = new();
    }
}
